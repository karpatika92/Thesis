type2unstringing=function(path,vipos,vjpos,vkpos,vlpos){
  #function removes vi from path by type1 unstringing
  vi=path[vipos]
  vj=path[vjpos]
  vk=path[vkpos]
  vl=path[vlpos]
  pl=length(path)
  #check if feasible
  viok=vipos>1
  vjok=vjpos>vipos
  vlok=vjpos<vlpos
  vkok=vkpos>vlpos & vkpos<pl
  newpath=rep(0,pl-1)
  if(viok&vjok&vlok&vkok){
    
    #beginning is the same as original path
    for (i in 1:(vipos-1)) {
      newpath[i]=path[i]
    }
    npi=vipos
    #next is vk
    newpath[npi]=path[vkpos]
    npi=npi+1
    #next is reversed path from vk to vlp1
    if(vkpos>(vlpos+1)){
      for (i in (vkpos-1):(vlpos+1)) {
        newpath[npi]=path[i]
        npi=npi+1
      }
    }else{if(!is.element(path[vlpos+1],newpath)){
      newpath[npi]=path[vlpos+1]
      npi=npi+1
    }}
      #next is vj-1
      if(!is.element(path[vjpos-1],newpath)& (vjpos-1)!=vipos){
        newpath[npi]=path[vjpos-1]
        npi=npi+1
      }
    #next is reversed path from vj-1 to vip1
    if((vjpos-1)>(vipos+1)){
      for (i in (vjpos-2):(vipos+1)) {
        newpath[npi]=path[i]
        npi=npi+1
      }}else{
        if(!is.element(path[vipos+1],newpath)){
          newpath[npi]=path[vipos+1]
          npi=npi+1
        }
      }
    #next is vj
    if(!is.element(path[vjpos],newpath)){
      newpath[npi]=path[vjpos]
      npi=npi+1
    }
    #next is original path from vj to vl
    if(vjpos<vlpos){
      for (i in (vjpos+1):vlpos) {
        newpath[npi]=path[i]
        npi=npi+1
      }}else{
        if(!is.element(path[vlpos],newpath)){
          newpath[npi]=path[vlpos]
          npi=npi+1
        }
      }
    #next is vkp1
    if(!is.element(path[vkpos+1],newpath)){
      newpath[npi]=path[vkpos+1]
      npi=npi+1
    }
    #next of from vk+1 to the end
    if((vkpos+1)<pl){
      for (i in (vkpos+2):pl) {
        newpath[npi]=path[i]
        npi=npi+1
      }
    }else{
      
        newpath[npi]=path[pl]
      
    }
    
  }else{newpath=path
  vi=NULL  
  print("UNfeasible TYPE 2 remove")
  print(c("VKOK",vkok,"VIOK",viok,"VJOK",vjok,"VLOK",vlok))
  print(c(vkpos,vipos,vjpos,vlpos))}
  returnvalue=list()
  returnvalue[[1]]=newpath
  returnvalue[[2]]=vi
  return(returnvalue)
}