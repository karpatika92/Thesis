type1unstringing=function(path,vipos,vjpos,vkpos){
  #function removes vi from path by type1 unstringing
  vi=path[vipos]
  vj=path[vjpos]
  vk=path[vkpos]
    viok=vipos<vkpos & vipos!=1
    vkok=vkpos>vipos & vkpos<vjpos
    vjok=vjpos<length(path)
    newpath=rep(0,length(path)-1)
  #check the condition that this is indeed a type 1 insertion
  if(vkok & viok & vjok){
    #construct the new path
    #the beginning is the same until vi-1
    for (i in 1:(vipos-1)) {
      newpath[i]=path[i]
    }
    npi=vipos
    #next vertex is vk
    newpath[npi]=vk
    npi=npi+1
    #next is reversed path from vk to vip1
    if(vkpos>(vipos+1)){
      for (i in (vkpos-1):(vipos+1)) {
        newpath[npi]=path[i]
        npi=npi+1
      }
    }
    #next vertex is vj
    newpath[npi]=path[vjpos]
    npi=npi+1
    #next is reversed path from vj to vkp1
    if(vjpos>(vkpos+1)){
      for (i in (vjpos-1):(vkpos+1)) {
        newpath[npi]=path[i]
        npi=npi+1
      }
    }else{
      if(!is.element(path[vkpos+1],newpath)){
        newpath[npi]=path[vkpos+1]
    npi=npi+1}}
    #next is vjp1
    if(!is.element(path[vjpos+1],newpath)){
      newpath[npi]=path[vjpos+1]
      npi=npi+1}
      #the rest is the same
      if((vjpos+1)<length(path)){
        for (i in (vjpos+2):length(path)) {
          newpath[npi]=path[i]
          npi=npi+1
        }
      }else{newpath[npi]=path[length(path)]}
    
    
  }else{newpath=path
  vi=NULL
  print("UNfeasible TYPE 1remove")
  print(c("VKOK",vkok,"VIOK",viok,"VJOK",vjok))
  print(c(vkpos,vipos,vjpos))}
    returnvalue=list()
    returnvalue[[1]]=newpath
    returnvalue[[2]]=vi
    return(returnvalue)
  
    
  
  
}
  