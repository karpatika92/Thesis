USTSP=function(path,adjacency,p,steps,graphics=FALSE,coord=NULL){
  #this function is the Unstringing and stringing procedure
  source("C:\\Users\\karpatika\\Documents\\pathlength.R")
  source("C:\\Users\\karpatika\\Documents\\pnbhd.R")
  source("C:\\Users\\karpatika\\Documents\\type1insertion.R")
  source("C:\\Users\\karpatika\\Documents\\type1inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2insertion.R")
  #setting up initial values
  #check if path has at least 4 points
  if(length(path)>6){
  optcost=pathlength(path,adjacency)
  ##print("LOL")
  bestpath=path
  t=1
  nogo=0
  t1s=0
  t2s=0
  t1us=0
  t2us=0
  originalcost=optcost
  noimprovement=0
  #STEP 2
  #n is the number of vertices in the path
  n=length(adjacency[1,]) #-1 because pf the future depot
  #UNSTRINGING
  #update p-neighborhood of all vertices
  nbhood=list()
  for (i in 1:n) {
    nbhood[[i]]=path[pnbhd(i,p,adjacency[,path])]
  }
  
  ##print("ALL NBHOODS")
  ##print(nbhood)
  #stop("SEE NBHOODS")
  tourlength=length(path)
  originalpath=path[2:(tourlength-1)]
  ####print("CHOOSABLE VERTICES: ")
  ####print(originalpath)
  ordering=permute(originalpath)
  #
  ####print("ORDER OF REINSERTION: ")
  ####print(ordering)
  #choose a vertex to be removed
  steps=length(ordering)
for (vertex in 1:steps) {
   ###print("PATH IN USTSP")
  ###print(path)
  if(graphics==TRUE & !is.null(coord)){
    #plotting lines of the tour at every 5th iteration
    if(vertex%%3==0){
      plot(coord,xlim=c(0,1),ylim=c(0,1))
      for (j in 1:tourlength) {
        segments(xy[path[j],1],xy[path[j],2],xy[path[j+1],1],xy[path[j+1],2],col = "red")
      } 
    }
  }
  
  
  removevertex=ordering[vertex]
  
  bestremovecost=9999
  bestinsertcost=9999
  besti=0
  bestj=0
  bestk=0
  bestl=0
  #try all possible unstringings and choose the best
  vipos=match(removevertex,path)
  #removevertex=path[vipos]
  vip1=path[vipos+1]
  vim1=path[vipos-1]
  ####print(c(vipos,removevertex,path))
  #type 1
  options=min(p,length(nbhood[[1]]))
  for (j in 1:options) {
    for (k in 1:options) {
      ####print("VIP1")
      ####print(vip1)
      ####print("NBHOOD[[vip1]]")
      ####print(nbhood[[vip1]])
      vj=nbhood[[vip1]][j]
      vk=nbhood[[vim1]][k]
      vjpos=match(vj,path)
      vkpos=match(vk,path)
    
      removecost=type1uscost(path,vipos,vjpos,vkpos,adjacency)
      if(removecost<bestremovecost){
        besti=vipos
        bestk=vkpos
        bestj=vjpos
        bestremovecost=removecost
        type=1
      }
    }
  }
  #after that go through all the type 2 unstringings
  for (j in 1:options) {
    for (k in 1:options) {
      for (l in 1:options) {
        vj=nbhood[[vip1]][j]
        vk=nbhood[[vim1]][k]
        vkpos=match(vk,path)
        vkp1=path[vkpos+1]
        ####print("VKP1")
        ####print(vkp1)
        ####print("LENGTH OF NBHOOD LIST")
        ####print(length(nbhood))
        ####print("NBHOOD")
        ####print(nbhood[[vkp1]])
        ####print("PATH")
        ####print(path)
        ####print("L")
        ####print(l)
        ####print("VL")
        ####print(nbhood[[vkp1]][1:(l-1)])
        vl=nbhood[[vkp1]][l]
        vjpos=match(vj,path)
        vlpos=match(vl,path)
        removecost=type2uscost(path,vipos,vjpos,vkpos,vlpos,adjacency)
        if(removecost<bestremovecost){
          besti=vipos
          bestk=vkpos
          bestj=vjpos
          bestl=vlpos
          bestremovecost=removecost
          type=2
        }
      }
    }
  }
  #check if removal was possible
  if(bestremovecost<999){
    
  if(type==1){
    newpath=type1unstringing(path,besti,bestj,bestk)[[1]]
    ####print("TYPE 1 UNSTRINGING")
    ####print(c("besti","bestj","bestk"))
    
    ####print(c(besti,bestj,bestk))
    ####print(c(removevertex,vj,vk))
    t1us=t1us+1
  }else{
    newpath=type2unstringing(path,besti,bestj,bestk,bestl)[[1]]
    ####print("TYPE2 UNSTRINGING")
    t2us=t2us+1
    ####print(c("besti","bestj","bestk","bestl"))
    
    ####print(c(besti,bestj,bestk,bestl))
    ####print(c(removevertex,vj,vk,vl))
    
    
  }
    ###print("AFTER UNSTRINGING")
    ###print(newpath)
  #after the unstringing, lets do the stringing aka reinserting the vertex
  #Update p-nbhd of all points
  type=0
  nbhood=list()
  for (i in 1:n) {
    nbhood[[i]]=newpath[pnbhd(i,p,adjacency[,newpath])]
  }
  options=min(p,length(newpath))
  ##print("OPTIONS")
  ##print(options)
  ###print("MOVED VERTEX")
  ###print(removevertex)
  ###print("NBHOOD OF RMVV")
  ###print(nbhood[[removevertex]])
  ###print("NBHOOD OF VIP1")
  for (i in 1:options) {
    for (j in 1:options) {
      for (k in 1:options) {
        vi=nbhood[[removevertex]][i]
        vipos=match(vi,newpath)
        vj=nbhood[[removevertex]][j]
        vjpos=match(vj,newpath)
        vip1=path[vipos+1]
        ####print("VIP1")
        ####print(vip1)
        ###print("NBHOOD[[vip1]]")
        ###print(nbhood[[vip1]])
        
        vk=nbhood[[vip1]][k]
        
        vkpos=match(vk,newpath)
        ##print("NBHOOD OF Vip1")
        ##print(nbhood[[vip1]])
        ##print("VK")
        ##print(vk)
        insertcost=type1inscost(newpath,removevertex,vipos,vjpos,vkpos,adjacency)
        ###print("T1 INSCOST")
        ###print(insertcost)
        if(insertcost<bestinsertcost){
          besti=vipos
          bestj=vjpos
          bestk=vkpos
          bestinsertcost=insertcost
          type=1
        }
        
        
      }
    }
  }
  #now check all the type 2 insertions
  for (i in 1:options) {
    for (j in 1:options) {
      for (k in 1:options) {
        for (l in 1:options) {
          
        
        vi=nbhood[[removevertex]][i]
        vipos=match(vi,newpath)
        vj=nbhood[[removevertex]][j]
        vjpos=match(vj,newpath)
        vip1=newpath[vipos+1]
        ####print("VIP1")
        ####print(vip1)
        ####print("NBHOOD[[vip1]]")
        ####print(nbhood[[vip1]])
        
        vk=nbhood[[vip1]][k]
        vkpos=match(vk,newpath)
        vjp1=newpath[vjpos+1]
        ####print("NEWPATH")
        ####print(newpath)
        ####print("VJP1")
        ####print(vjp1)
        ####print("NBHOOD[[vJp1]]")
        ####print(nbhood[[vjp1]])
        ####print("L")
        ####print(l)
        vl=nbhood[[vjp1]][l]
        vlpos=match(vl,newpath)
        insertcost=type2inscost(newpath,removevertex,vipos,vjpos,vkpos,vlpos,adjacency)
        if(insertcost<bestinsertcost){
          besti=vipos
          bestj=vjpos
          bestk=vkpos
          bestl=vlpos
          bestinsertcost=insertcost
          type=2
        }
        
        
      }
    }
    }
  }
  #now that the best insertion cost is found, execute the best move
  if(type==1){
    newnewpath=type1insertion(removevertex,newpath,besti,bestj,bestk)
    ####print("TYPE 1 STRINGING")
    t1s=t1s+1
  }else if (type==2){
    newnewpath=type2insertion(removevertex,newpath,besti,bestj,bestk,bestl)
    ####print("TYPE 2 STRINGING")
    t2s=t2s+1
  }else{
    newnewpath=path
  }
  ###print("INSTYPE")
  ###print(type)
  ###print("AFTER STRINGING")
  ###print(newnewpath)
  newpathlength=pathlength(newnewpath,adjacency)
  ####print(c("New pathlength: ",newpathlength))
  ####print(c("OPTIMAL COST: ",optcost))
  ####print(c("ORIGINAL PATH: "))
  ####print(path)
  ####print(c("AFTER REMOVAL: "))
  ####print(newpath)
  ####print(c("AFTER REINSERTION: "))
  ####print(newnewpath)
  ####print(c("removevertex","besti","bestj","bestk","bestl"))
  
  ####print(c(removevertex,besti,bestj,bestk,bestl))
  ####print("Best insertion cost: ")
  ####print(bestinsertcost)
  #gebasz csekk
  if(is.element(0,newnewpath)){
    stop("0 in the path")
  }
  if(length(unique(newnewpath))>(length(path)+1)){
    stop("Duplicate in the path")
  }
  if(length(newnewpath)<length(path)){
    ###print("VERTEX")
    ###print(vertex)
    stop("VERTEX MISSING")
  }
  if(newpathlength<optcost){
    optcost=newpathlength
    bestpath=newnewpath
    noimprovement=0
    ###print("!!!!IMPROVEMENT!!!!")
  }else{
    noimprovement=noimprovement+1
    ###print(c("MOVES SINCE IMPROVEMENT: ",noimprovement))
    newnewpath=bestpath
  }
  path=newnewpath
  }else{nogo=nogo+1}
}
  optcost=pathlength(bestpath,adjacency)
  ###print(c("type 1 unstringing: ",t1us))
  ###print(c("type 2 unstringing: ",t2us))
  ###print(c("type 1 stringing: ",t1s))
  ###print(c("type 2 unstringing: ",t2s))
  ###print(c("NOGOES: ",nogo))
  ###print(c("ORIGINAL COST: ",originalcost))
  ###print(c("NEW COST :",optcost))
  }else{bestpath=path}
  return(bestpath)
}