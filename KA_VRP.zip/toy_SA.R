rm(list=ls())
set.seed(2121434)
graphics.off()

require(stats)
source("C:\\Users\\karpatika\\Documents\\pathlength.R")
source("C:\\Users\\karpatika\\Documents\\3_opt.R")

#Generate random points in clusters
#number of clusters
nc=9
#number of point sin each cluster
np=10
row=3
column=nc/row
xy=array(dim=c(np,2,nc))
#specify shift
shift=2
#specify capacity
capacity=3
#¶specify max tour length
maxlength=30

#2 nested for cycles for row and column
for (i in 1:row) {
  for (j in 1:column) {
    xy[, ,(i-1)*3+j]=matrix(runif(np*2),ncol=2)+matrix(nrow=np,ncol=2,data=c(rep(shift*(i-1),np),rep(shift*(j-1),np)))
    
  }
}

txy=xy[, ,1]
for (i in 2:nc) {
  txy=rbind(txy,xy[,,i])
}
#generate x and y coordinates of points
txy=rbind(txy,c(2.5,2.5))
plot(txy,xlim=c(0,5),ylim=c(0,5))
#so the data is generated
#generate euclidean distance matrix by calculating the distance of each pointpair with 2 for cycles
adjacency=as.matrix(dist(txy))
#assign capacities to points
cap=runif(length(txy[,1])-1,min=0,max=1)
#attach capacities to point matrix
txy=cbind(txy,c(cap,0))
#########################################################################


#Clarke-Wright algorithm
#Create a list of paths that contain only 1 vertex
#list of paths containing all visited vertices
paths=list()
pathlengths=list()
pathcap=list()
#vector that tells you the number of the parth the ith vertex is in
points_in_path=c(rep(0,length(txy[,1])))

for (i in 1:(length(txy[,1])-1)) {
  paths[[i]]=c(length(txy[,1]),i,length(txy[,1]))
  pathlengths[[i]]=adjacency[paths[[i]][1],paths[[i]][2]]
  pathcap[[i]]=txy[i,3]
  points_in_path[i]=i
}
#calculate total length
objfun=Reduce("+",pathlengths,accumulate = FALSE)
#calculate the sequantial list for adding points to a path http://pure.au.dk/portal-asb-student/files/36025757/Bilag_E_SAVINGSNOTE.pdf
#formula for savings: c0j+ci0-cij
#savings for all custome pairs
savings=matrix(rep(0,np*nc*np*nc),nrow=np*nc,ncol=np*nc)
for (i in 1:(np*nc)) {
  for (j in i:(np*nc)) {
    if(!(j==i)){
      savings[i,j]=adjacency[i,np*nc+1]+adjacency[np*nc+1,j]-adjacency[i,j]
      
    }
  }
}

#now calculate the best moves
m=1
moves=list()
savings2=savings
for (i in 1:(np*nc)) {
  for (j in i:(np*nc)) {
    if(savings2[which(savings2==max(savings2))]==0){break}
    moves[[m]]=which(savings2==max(savings2),arr.ind=TRUE)
    
    savings2[moves[[m]]]=0
    m=m+1
    
 } 
}

#now start executing the moves
m=length(moves)
for (i in 1:m) {
  

target=moves[[i]][1]
candidate=moves[[i]][2]
targetroute=points_in_path[target]
candidateroute=points_in_path[candidate]

#check feasibility conditions
#capacity
feasible_cap=pathcap[[targetroute]]+txy[candidate,3]<capacity
#length - NOT YET
#pathlengths[[targetroute]]+
#is the point already moved?
movable=length(paths[[points_in_path[candidate]]])==3
#if capacity and length are OK, then we add the vertice to the path
if(feasible_cap & movable){
  #insertion
  index=which(paths[[targetroute]]==target)
  val=c(paths[[targetroute]],candidate)
  id=c(seq_along(paths[[targetroute]]),index+0.5)
  paths[[targetroute]]=val[order(id)]
  #update path capacity
  pathcap[[targetroute]]=pathcap[[targetroute]]+txy[candidate,3]
  pathcap[[candidateroute]]=0
  #update path lengths
  pathlengths[[candidateroute]]=0
  pathlengths[[targetroute]]=pathlength(paths[[targetroute]],adjacency)
    #delete original path
  paths[[points_in_path[candidate]]]="NaN"
  #update point location
  points_in_path[candidate]=targetroute
  #update objective function
  objfun=Reduce("+",pathlengths)
  }
}
emptypath=c(0)
j=1
#remove empty entries from the pathlists
for (i in 1:length(paths)) {
  if(paths[[i]]=="NaN"){
    emptypath[j]=i
    j=j+1
  }
}
paths[emptypath]=NULL
pathlengths=pathlengths[pathlengths!=0]
#####Untangle the routes by permuting neighbouring elements###########

#check every 3 permutation in a route
numpath=length(paths)
#for (i in 1:numpath) {
#  paths[[i]]=threeopt(paths[[i]],adjacency)
  pathlengths[[i]]=pathlength(paths[[i]],adjacency)
  
}

#drawing the final solution
dev.new(width=5, height=4)
plot(txy[,1],txy[,2],xlim=c(0,5),ylim=c(0,5),col="black")
#loop for every path
numpath=length(paths)
for (i in 1:numpath) {
  

#loop for each path
len=length(paths[[i]])-1
for (j in 1:len) {
  segments(txy[paths[[i]][j],1],txy[paths[[i]][j],2],txy[paths[[i]][j+1],1],txy[paths[[i]][j+1],2],col = rainbow(numpath)[i])
  
}
}
