consistencycheck=function(pathlist){
  #pathlist must be a list
  #every vertex is contained in exactly 1 path
  numpaths=length(pathlist)
  pathlengths2=rep(0,numpaths)
  violation1=FALSE
  zeroviol=FALSE
  zeroviol2=FALSE
  for (i in 1:numpaths) {
    pathlengths2[i]=length(pathlist[[i]])
  }
  numvertices=sum(pathlengths2)-numpaths*2
  vertexinpath=rep(0,numvertices)
  #print("PATHLIST IN CONSCHEK")
  #print(pathlist)
  print("NUMVERTICSE IN CONSCHECK")
  print(numvertices)
  #print("NUMPATHS IN CONSCHECK")
  #print(numpaths)
  #print("PATHLENGTHS2 in CONSCHECK")
  #print(pathlengths2)
  for (i in 1:numpaths) {
    for (j in 2:(pathlengths2[i]-1)) {
     
      #print(c(i,j))
      

      if(vertexinpath[ pathlist[[i]][j] ]==0){
      vertexinpath[ pathlist[[i]][j] ]=i}else{
        print("VERTIEX IN MULTIPLE PATHS")
        print(        c("PATH 1 ",vertexinpath[pathlist[[i]][j]],"PATH2 ",i,"VERTEX: ",pathlist[[i]][j]))
        print("PATHLIST")
        print(pathlist)
        
        violation1=TRUE
      }
      #check if paths contain 0
      if(pathlist[[i]][j]==0){
        print(c("There is a 0 in path ",i))
        zeroviol=TRUE
      }
      
    }
  }
  "CHECK if every vertex is in one of the paths"
  if(is.element(0,pathlist)){
    print("0 is in vertexinset")
    zeroviol2=TRUE
  }
  #print final answer
  if(zeroviol2 | zeroviol | violation1){
    stop("SOLUTION IS CORRUPTED")
  }else{
    print("SOLUTION IS OK")
  }
}