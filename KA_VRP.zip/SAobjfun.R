SAobjfun=function(pathlist,adjacency){
  numpath=length(pathlist)
  #print("NUMPATHS IN OBJFUN")
  #print(numpath)
  pathlengths=rep(0,numpath)
  for (i in 1:numpath) {
    #print(c("PATHNUMBER: ",i))
    #print(pathlist[[i]])
    pathlengths[i]=pathlength(pathlist[[i]],adjacency)
    #print(pathlengths)
  }
  result=sum(pathlengths)
  return(result)
}