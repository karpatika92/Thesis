feasabilitycheck=function(pathlist,lengthconstraint,capacityconstraint,adjacency,txy){
  #print("FSCHECK")
  
    numpaths=length(pathlist)
  lengthok=rep(FALSE,numpaths)
  capok=rep(FALSE,numpaths)
  truth=FALSE
  #print(txy)
  for (i in 1:numpaths) {
    #print(txy[pathlist[[i]],3])
    capok[i]=sum(txy[pathlist[[i]],3])<capacityconstraint
    #print(sum(txy[pathlist[[i]],3]))
    #print(pathlist[[i]])
    #print()
    #print(sum(txy[pathlist[[i]]],3))
    lengthok[i]=pathlength(pathlist[[i]],adjacency)<lengthconstraint
  }
  truth=prod(capok)*prod(lengthok)
  print(c("CAPACITY",prod(capok)))
  print(c("LENGTH",prod(lengthok)))
  #print(txy)
  return(truth)
}