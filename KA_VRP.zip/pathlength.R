pathlength<- function(pointlist,distancematrix){
  if(is.matrix(distancematrix) &  is.vector(pointlist)){
    result=0
    l=length(pointlist)
  for (i in 1:(l-1)) {
    result=result+distancematrix[pointlist[i],pointlist[i+1]]
  }
  } else {
    result=NULL
  }
  return(result)
}