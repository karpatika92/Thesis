rm(list=ls())
set.seed(2121434)
graphics.off()

require(stats)
source("C:\\Users\\karpatika\\Documents\\pathlength.R")

#Generate random points in clusters
#number of clusters
nc=4
#number of point sin each cluster
np=2
row=2
column=nc/row
xy=array(dim=c(np,2,nc))
#specify shift
shift=2
#specify capacity
maxcap=3
#¶specify max tour length
maxlength=30

#2 nested for cycles for row and column
for (i in 1:row) {
  for (j in 1:column) {
    xy[, ,(i-1)*row+j]=matrix(runif(np*2),ncol=2)+matrix(nrow=np,ncol=2,data=c(rep(shift*(i-1),np),rep(shift*(j-1),np)))
    
  }
}

txy=xy[, ,1]
for (i in 2:nc) {
  txy=rbind(txy,xy[,,i])
}
#generate x and y coordinates of points
txy=rbind(txy,c(2.5,2.5))
#so the data is generated
#generate euclidean distance matrix by calculating the distance of each pointpair with 2 for cycles
adjacency=as.matrix(dist(txy))
#assign capacities to points
cap=runif(length(txy[,1])-1,min=0,max=1)
#attach capacities to point matrix
txy=cbind(txy,c(cap,0))
#########################################################################

##Convert xy coordinates to polar coordinates
##subtract the coordinates of the depot from every pair so that the data is centered
numpoints=np*nc
depox=txy[numpoints+1,1]
depoy=txy[numpoints+1,2]

txy[,1]=txy[,1]-depox
txy[,2]=txy[,2]-depoy

#Sweep algorithm
#list of paths containing all visited vertices
paths=list()
pathlengths=list()
pathcap=list()

##convert to polar coordinates
#angle by arc tangent
#pxy=matrix(nrow = numpoints+1,ncol=3)
txy=cbind(txy,atan2(txy[,2],txy[,1])*180/pi)
#pxy[,1][pxy[,1]<0]=pxy[,1][pxy[,1]<0]+360
#distance from the origin
txy=cbind(txy,adjacency[,numpoints+1])
#pxy[,2]=adjacency[,numpoints+1]
#copy the capacities

#remove depo before sorting
pxy=pxy[-nrow(pxy),]
txy=txy[-nrow(txy),]



#sort according to angle
txy=txy[order(txy[,4]),]

#pxy=pxy[order(pxy[,1]),]


#add the depo as last again
#pxy=rbind(pxy,c(0,0,0))
txy=rbind(txy,c(rep(0,length(txy[1,]))))
#add labels
#pxy=cbind(pxy,c(seq(1:numpoints),0))
txy=cbind(txy,c(seq(1:numpoints),0))

#compute new distance matrix
adjacency=as.matrix(dist(txy[,1:2]))


plot(txy,xlim=c(-2.5,2.5),ylim=c(-2.50,2.5))
text(txy[,1],txy[,2],labels = txy[,6],col="blue",pos=3)