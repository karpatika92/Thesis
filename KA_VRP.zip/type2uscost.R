type2uscost=function(path,vipos,vjpos,vkpos,vlpos,adjacency){
  #function removes vi from path by type1 unstringing
  vi=path[vipos]
  vj=path[vjpos]
  vk=path[vkpos]
  vl=path[vlpos]
  vip1=path[vipos+1]
  vim1=path[vipos-1]
  vjm1=path[vjpos-1]
  vlp1=path[vlpos+1]
  vkp1=path[vkpos+1]
  pl=length(path)
  #check if feasible
  viok=vipos>1
  vjok=vjpos>vipos
  vlok=vjpos<vlpos
  vkok=vkpos>vlpos &vkpos<pl
  if(viok&vjok&vlok&vkok){
    inscost=adjacency[vip1,vj]+adjacency[vl,vkp1]+adjacency[vim1,vk]+adjacency[vlp1,vjm1]-adjacency[vi,vip1]-adjacency[vim1,vi]-adjacency[vjm1,vj]-adjacency[vl,vlp1]-adjacency[vk,vkp1]
  }else{inscost=9999}
  return(inscost)
}
    