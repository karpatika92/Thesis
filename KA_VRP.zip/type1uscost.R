type1uscost=function(path,vipos,vjpos,vkpos,adjacency){
  #function removes vi from path by type1 unstringing
  vi=path[vipos]
  vj=path[vjpos]
  vk=path[vkpos]
  vip1=path[vipos+1]
  vim1=path[vipos-1]
  vjp1=path[vjpos+1]
  vkp1=path[vkpos+1]
  viok=vipos<vkpos & vipos!=1
  vkok=vkpos>vipos & vkpos<vjpos
  vjok=vjpos<length(path)
  #check the condition that this is indeed a type 1 insertion
  if(vkok & viok & vjok){
  inscost=adjacency[vim1,vk]+adjacency[vip1,vj]+adjacency[vkp1,vjp1]-adjacency[vim1,vi]-adjacency[vi,vip1]-adjacency[vk,vkp1]-adjacency[vj,vjp1]  
  }else{inscost=9999}
  return(inscost)
}
    