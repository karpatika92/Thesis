type2insertion=function(insertvertex,path,vipos,vjpos,vkpos,vlpos){
  pl=length(path)
  plok=pl>5
  newroute=c(rep(0,pl+1))
  #check feasibility of insertion
  vivjok=vipos<vjpos
  vkok=vkpos!=vjpos & vkpos!=(vjpos+1) & vkpos>vjpos
  vlok=vlpos!=vipos & vlpos!=(vipos+1) & vlpos>vipos & vlpos<vjpos
  if(vivjok&vkok&vlok&plok){
    #the beginning until vi is the same
    for (i in 1:vipos) {
      newroute[i]=path[i]
    }
    #then we insert the added vertex
    npi=vipos+1
    newroute[npi]=insertvertex
    npi=npi+1
    #now insert vj to the path
    newroute[npi]=path[vjpos]
    npi=npi+1
    ###print("Phase1")
    ###print(newroute)
    #now the reversed path vj-vl
    if((vjpos-1)>vlpos){
      for (i in (vjpos-1):vlpos) {
        newroute[npi]=path[i]
        npi=npi+1
      }}else{newroute[npi]=path[vjpos-1]
      npi=npi+1}
    ###print("Phase2")
    ###print(newroute)
    #the next step is to insert vj+1
    newroute[npi]=path[vjpos+1]
    npi=npi+1
    #now from vj+1 to vk-1 the route is the same
    if((vjpos+2)<(vkpos-1)){
      for (i in (vjpos+2):(vkpos-1)) {
        newroute[npi]=path[i]
        npi=npi+1
      }
    }else{
      if(!is.element(path[vkpos-1],newroute)){
        newroute[npi]=path[vkpos-1]
    npi=npi+1}}
    ###print("Phase3")
    ###print(newroute)
    #the next vertex is vl-1
    #no need for if, this is guaranteed to work
    newroute[npi]=path[vlpos-1]
    npi=npi+1
    #now from vl-1 to vi+1
    ###print("Phase3.5")
    ###print(newroute)
    if((vlpos-2)>(vipos+1)){
      for (i in (vlpos-2):(vipos+1)) {
        newroute[npi]=path[i]
        npi=npi+1
      }
    }else{
      if(!is.element(path[vlpos-2],newroute)){
      newroute[npi]=path[vlpos-2]
      npi=npi+1
      }
    }
    #next vertex is vk
    if(!is.element(path[vkpos],newroute)){
    newroute[npi]=path[vkpos]
    npi=npi+1
}
    ###print("Phase4")
    ###print(newroute)
    #the last segment is from vk to the end
    if((vkpos+1)<pl){
      for (i in (vkpos+1):pl) {
      newroute[npi]=path[i]
      npi=npi+1
      }
    }else{newroute[npi]=path[pl]}
    
    
  }else{
    ##print("Unfeasible insertion")
    ##print(vivjok)
    ##print(plok)
    #
    ##print(vkok)
    ##print(vlok)
    newroute=path
  }
  return(newroute)
}