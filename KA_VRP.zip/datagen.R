rm(list=ls())
set.seed(2121434)
require(stats)

#Generate random points in clusters
#number of clusters
nc=9
#number of point sin each cluster
np=5
row=3
column=nc/row
xy=array(dim=c(np,2,nc))
#specify shift
shift=2
#specify capacity
capacity=20
#¶specify max tour length
maxlength=30

#2 nested for cycles for row and column
for (i in 1:row) {
  for (j in 1:column) {
    xy[, ,(i-1)*3+j]=matrix(runif(np*2),ncol=2)+matrix(nrow=np,ncol=2,data=c(rep(shift*(i-1),np),rep(shift*(j-1),np)))
    
  }
}

txy=xy[, ,1]
for (i in 2:nc) {
  txy=rbind(txy,xy[,,i])
}
#generate x and y coordinates of points
txy=rbind(txy,c(2.5,2.5))
plot(txy,xlim=c(0,5),ylim=c(0,5))
#so the data is generated
#generate euclidean distance matrix by calculating the distance of each pointpair with 2 for cycles
adjacency=as.matrix(dist(txy))

#Clarke-Wright algorithm
#Create a list of paths that contain only 1 vertex

paths=list()
pathlengths=list()
pathcap=list()

#assign capacities to points
cap=runif(90,min=0,max=1)
#attach capacities to point matrix
txy=cbind(txy,c(cap,0))
for (i in 1:length(txy[,1])) {
  paths[[i]]=c(91,i)
  pathlengths[[i]]=adjacency[paths[[i]][1],paths[[i]][2]]
  pathcap[[i]]=txy[i,3]
}
#calculate total length
objfun=Reduce("+",pathlengths)
#calculate the sequantial list for adding points to a path http://pure.au.dk/portal-asb-student/files/36025757/Bilag_E_SAVINGSNOTE.pdf
#formula for savings: c0j+ci0-cij
#savings for all custome pairs
savings=matrix(rep(0,np*nc*np*nc),nrow=np*nc,ncol=np*nc)
for (i in 1:(np*nc)) {
  for (j in i:(np*nc)) {
    if(!(j==i)){
      savings[i,j]=adjacency[i,np*nc+1]+adjacency[np*nc+1,j]-adjacency[i,j]
      
    }
  }
}

#now calculate the best moves
m=1
moves=list()
savings2=savings
for (i in 1:(np*nc)) {
  for (j in i:(np*nc)) {
    if(savings2[which(savings2==max(savings2)]==0){break}
    moves[[m]]=which(savings2==max(savings2),arr.ind=TRUE)
    
    savings2[moves[[m]]]=0
    m=m+1
    
 } 
}

#now start executing the moves


