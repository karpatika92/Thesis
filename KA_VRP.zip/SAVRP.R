SimulatedAnnealingVRP=function(numvertices,pathlist,adjacency,schedule="linear",maxiter=1000,maxtemp=100,mintemp=1,lengthconstraint,txy,maxcapacity,graphics=TRUE,diag=FALSE){
  #pathlist is an initial solution to the problem
  #the program expects this to be a list of vectors, where the first and the last element of each vector is the depot
  #first calculate the cost of the initial solution
  source("C:\\Users\\karpatika\\Documents\\pathlength.R")
  source("C:\\Users\\karpatika\\Documents\\coolingfunction.R")
  source("C:\\Users\\karpatika\\Documents\\3_opt.R")
  source("C:\\Users\\karpatika\\Documents\\type1insertion.R")
  source("C:\\Users\\karpatika\\Documents\\type1inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2insertion.R")
  source("C:\\Users\\karpatika\\Documents\\remove.R")
  source("C:\\Users\\karpatika\\Documents\\pnbhd.R")
  source("C:\\Users\\karpatika\\Documents\\GENItsp.R")
  source("C:\\Users\\karpatika\\Documents\\USTSP.R")
  source("C:\\Users\\karpatika\\Documents\\SAproposal.R")
  source("C:\\Users\\karpatika\\Documents\\SAobjfun.R")
  source("C:\\Users\\karpatika\\Documents\\feasabilitycheck.R")
  ##  Open a new default device.
  if(graphics){
  get( getOption( "device" ) )()
  
  ##  Set up plotting in two rows and three columns, plotting along rows first.
  
  par( mfrow = c( 2, 2 ) )
  }
  #create necessary statistics of solution
  objfunvector=rep(0,maxiter)
  temperature=rep(0,maxiter)
  feasible=0
  msf=0
 
  ornumpaths=length(pathlist)
  histpathlengths=matrix(rep(0,maxiter*ornumpaths),nrow=ornumpaths,ncol=maxiter)
  nfif=0
  acceptmove=0
  worsemoves=0
  bettermoves=0
  wamoves=0
  msa=0
  noaccept=0
  iter=1
  nbs=0
  nbstep=0
  ###print(pathlist)
  
  #print("LOL2")
  initialcost=SAobjfun(pathlist,adjacency)
  ###print("LOL")
  currentcost=initialcost
  bestcost=initialcost
  bestfeasiblecost=bestcost
  bestpath=pathlist
  bestfeasiblepath=pathlist
  p=10
  numpaths=length(pathlist)
  for (iter in 1:maxiter) {
    if(diag){
    print(c("SA ITERATION: ",iter," / ",maxiter))
      print(msf)
    }
    if(feasabilitycheck(pathlist,lengthconstraint,maxcapacity,adjacency,txy)==1){
      msf=0
      if(SAobjfun(pathlist,adjacency)<bestfeasiblecost){
        bestfeasiblepath=pathlist
      }
      
    }
    if(msf>500){
      numpaths=length(pathlist)
      print("APPLYING US FOR FEASABILITY")
      for (i in 1:numpaths) {
        pathlist[[i]]=USTSP(pathlist[[i]],adjacency,p=5,steps=length(pathlist[[i]]))
        
      }
      fsbl=feasabilitycheck(pathlist,lengthconstraint,maxcapacity,adjacency,txy)
      
      if(fsbl!=1){
        print("USTSP NOT SUCCESFUL")
      pathlist=bestfeasiblepath
      msf=0}else{
        print("SUCCESS")
        msf=0
        if(SAobjfun(pathlist,adjacency)<bestfeasiblecost){
          bestfeasiblepath=pathlist
        }
        
        }
    }
    feasible=0
    numpaths=length(pathlist)
    pathlengths=rep(0,numpaths)
    pathlengths2=rep(0,numpaths)
    pathcapacity=rep(0,numpaths)
    vertexinpath=rep(0,numvertices)
    
#print("BEFORE DELETION")
  ####print(numpaths)
  for(i in 1:numpaths){
    #print("I")
    #print(i)
    #print("NUMPATHS")
    #print(numpaths)
    #print("PATHLIST")
    #print(pathlist)
    pathlengths[i]=pathlength(pathlist[[i]],adjacency)
    pathlengths2[i]=length(pathlist[[i]])-2
    pathcapacity[i]=sum(txy[pathlist[[i]],3])
    for (j in 2:(pathlengths2[i]+1)) {
      vertexinpath[pathlist[[i]][j]]=i
    }
  }
  ####print("PATHCAPACITY")
   ####print(pathcapacity)
  ####print("pathlengths2")
  ####print(pathlengths2)
  
  #delete empty paths
  ###print(length(which(pathlengths2==0)))
  if(length(which(pathlengths2==0))>0){
    ###print(which(pathlengths2==0))
    ###print(pathlist[[which(pathlengths2==0)]])
    pathlist[[min(which(pathlengths2==0))]]=NULL
    ####print(pathlist)
    #stop("PATH DELETED")
  }
   #recount paths
     numpaths=length(pathlist)
     ####print(numpaths)
     pathlengths=rep(0,numpaths)
     pathlengths2=rep(0,numpaths)
     vertexinpath=rep(0,numvertices)
     pathcapacity[i]=rep(0,numvertices)
    for(i in 1:numpaths){
      ##print("i IN RECOUNTING")
      ##print(i)
      pathlengths[i]=pathlength(pathlist[[i]],adjacency)
      pathlengths2[i]=length(pathlist[[i]])-2
      pathcapacity[i]=sum(txy[pathlist[[i]],3])
      
      for (j in 2:(pathlengths2[i]+1)) {
        vertexinpath[pathlist[[i]][j]]=i
      }     
      ##print("PATHLENGTHS")
      ##print(pathlengths)
      
    }
  
    
  #print(c("ITERATION: ",iter))
  #print("PATHLENGTHS IN SAVRP")
  ####print(pathlengths)
  #pathlengths="LÓFASZ"
  ####print("NUMPATHS IN SAVRP")
  ####print(numpaths)
  #vertexinpath is a vector which contains path number for every vertex, lets calcuate it
  newpathlist=SAproposal(pathlist,numpaths,pathlengths,pathcapacity=pathcapacity,numvertices,adjacency,p,vertexinpath,lengthconstraint = lengthconstraint,capconstraint=maxcapacity,txy)
  #print("LOL3")
  #compare two lists
  noprop=FALSE
  #length
  pl2=length(newpathlist)
  pl1=length(pathlist)
  ####print("PL1")
  ####print(pl1)
  ####print("PL2")
  ####print(pl2)
  truthvector=rep(FALSE,pl1)
  if(pl1==pl2){
    for(cucc in 1:pl1){
   ####print("PATHLIST[[cucc]]")
     ####print(pathlist[[cucc]])
     ####print("NEWPATHLIST[[cucc]]")
    ####print(newpathlist[[cucc]])
    truthvector[cucc]=prod(unlist(newpathlist[[cucc]])==unlist(pathlist[[cucc]]))
      ##print(truthvector)
    noprop=(sum(truthvector)==pl1)
    }
  }else{noprop=TRUE}
  if(noprop){
    print("NO FEASIBLE INSERTION FOUND in SAVRP")
    nfif=nfif+1
    ###print(nfif)
  }else{
    
  ####print("PROPOSAL MADE")
  ####print(newpathlist)
  objfun=SAobjfun(newpathlist,adjacency)
  ####print("OBJFUN CALCULATION OK")
  #decide if new solution is accepted
  if(currentcost>objfun){
    #auto accept
    pathlist=newpathlist
    acceptmove=acceptmove+1
    bettermoves=bettermoves+1
    msa=msa+1
    if(objfun<bestcost){
      bestcost=objfun
      bestpath=newpathlist
      ###print("NEW BEST SOLUTION FOUND")
      nbs=nbs+1
      nbstep=iter
      
      
    }
  }else{
    #calculate temperature
    msa=msa+1
    ####print(iter)
    temp=coolingfunction(maxtemp,mintemp,iter=iter,maxiter=maxiter,shape=schedule)
    #transform
    #◘##print("TEMP SA")
    ###print("MAXTEMP")
    ###print(maxtemp)
    ###print("MINTEMP")
    ###print(mintemp)
    ###print("ITER")
    ###print(iter)
    ###print("MAXITER")
    ###print(maxiter)
    ###print("SHAPE")
    ###print(schedule)
    
    change=(currentcost-objfun)
    propp=exp((change/temp))
    accp=runif(1)
    ##print("PROPP SA")
    ##print(propp)
    ##print("ACCP SA")
    ##print(accp)
    if(propp>accp){
      pathlist=newpathlist
      acceptmove=acceptmove+1
      worsemoves=worsemoves+1
      wamoves=wamoves+1
      ###print("WORSE MOVE ACCEPTED")
    }else{
      #change nothing
      worsemoves=worsemoves+1
      noaccept=noaccept+1
      ###print(c("PROPOSAL NOT ACCEPTED, MOVES SINCE ACCEPTANCE: ",msa))
    }
  }
  tolerance=1000
  if(msa>tolerance){
    pathlist=bestfeasiblepath
    msa=0
  }
  }
  ####print("LOL")
  currentcost=SAobjfun(pathlist,adjacency)
  objfunvector[iter]=currentcost
  ####print("length(histpathlengths[,iter])")
  ####print(length(histpathlengths[,iter]))
  ####print("length(pathlengths)")
   ####print(length(pathlengths))
  
  if(length(pathlengths)<ornumpaths){
  histpathlengths[,iter]=c(pathlengths,rep(0,ornumpaths-length(pathlengths)))}else{
    histpathlengths[,iter]=pathlengths
  }
  if(iter>50){
  if(objfunvector[iter]==objfunvector[iter-50]){
    pathlist=bestfeasiblepath
  }}
  if(max(pathlengths)>1.5*lengthconstraint){
    pathlist[[which.max(pathlengths)]]=USTSP(pathlist[[which.max(pathlengths)]],adjacency,p=5,steps=length(pathlist[[which.max(pathlengths)]]))
    if(pathlength(pathlist[[which.max(pathlengths)]],adjacency)>1.5*lengthconstraint){
    pathlist=bestfeasiblepath}
  }
  feasible=feasabilitycheck(pathlist,lengthconstraint,maxcapacity,adjacency,txy)
  msf=(msf+1)*(1-feasible)

  
  ####print(c("MAXtemp",maxtemp))
  ####print(c("MINTEMP",mintemp))
  ####print(c("ITER",iter))
  ####print(c("shape",schedule))
  ####print(c("MAXITER",maxiter))
  temperature[iter]=coolingfunction(maxtemp=maxtemp,mintemp=mintemp,iter=iter,maxiter=maxiter,shape=schedule)
   ####print(temperature)
  #update plot if iteration is dividible by 5
  ####print("ITER")
  ####print(iter)
  ####print(iter%%50)
  ####print(iter%%50==0)
  ####print(pathlist[[i]])
  #if(iter%%1499==0){
    #if(len>6){
     # ###print("ATTEMPTING USTSP")
      #pathlist[[i]]=USTSP(pathlist[[i]],adjacency,6,15)
      
   # }}
  
  if((iter%%50==0|iter==1|iter==maxiter) & graphics){

    
        plot(txy,xlim=c(0,max(txy[,1])),ylim=c(0,max(txy[,2])),main="PATHS",cex.lab=1.1)
    text(msf)
    numpath=length(pathlist)
    for (i in 1:numpath) {
      
      len=length(pathlist[[i]])-1
      
      #loop for each path
      for (j in 1:len) {
        segments(txy[pathlist[[i]][j],1],txy[pathlist[[i]][j],2],txy[pathlist[[i]][j+1],1],txy[pathlist[[i]][j+1],2],col = rainbow(numpath)[i])
      }
    }
   #plot OBJECTIVE FUNCTION
    ##  The second plot is located in row 1, column 2:
    
    plot( objfunvector, col = "blue", main = "OBJECTIVE FUNCTION", cex.lab = 1.1 ,type = "l")
    
    #also plot temperature
    ####print("PLOTTING TEMPERATURE")
    ####print(typeof(temperature))
    plot( temperature, col = "springgreen4", main = "TEMPERATURE",
          cex.lab = 1.1,type = "l" )
    
    #plot(runif(10),col="red",main="plot 3",cex.lab=1,1,type="l")
    #emptyplot
    #plot.new()
    plot(0,0,xlim = c(1,maxiter),ylim = c(0,2*lengthconstraint),type = "l")
    
    cl <- rainbow(ornumpaths)
    
    for (i in 1:ornumpaths){
      lines(1:maxiter,histpathlengths[i,],col = cl[i],type = 'l')
    }
  }

  
  
  }
  ####print(c("ACCEPTED MOVES: ",acceptmove))
  ####print(c("DECAYING MOVES: ",worsemoves))
  ####print(c("DECAYING MOVES THAT WERE ACCEPTED: ",wamoves))
  ####print(c("BEST SOLUTIONS FOUND: ",nbs))
  ####print(c("NO FEASIBLE INSERTION FOUND: ",nfif))
  ####print(vertexinpath)
  temp=coolingfunction(maxtemp,mintemp,iter=iter,maxiter=maxiter,shape=schedule)
  ##print(temp)
  returnlist=list()
  returnlist[[1]]=bestfeasiblepath
  returnlist[[2]]=pathlist
  return(returnlist)
}