coolingfunction=function(maxtemp,mintemp,maxiter,iter,shape="linear",lambda=1){
  require(stats)
  period=maxiter/5
  switch(shape,
         "linear"=mintemp+(maxtemp-mintemp)*((maxiter-iter))/maxiter,
         "exponential"=exp(-(maxtemp-mintemp)*(iter/maxiter)*lambda),
         "sinusoid"=(maxtemp-mintemp)*exp(-(iter/maxiter)*lambda)*(sin((2*pi/period)*(iter-1))+1)
         )
  
}