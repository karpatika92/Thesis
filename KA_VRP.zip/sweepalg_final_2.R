sweepalg_final=function(txy,adjacency,maxlength,maxcap){
  require(stats)
  source("C:\\Users\\karpatika\\Documents\\pathlength.R")
  source("C:\\Users\\karpatika\\Documents\\3_opt.R")
  print("STARTING SWEEP")
  paths=list()
  pathlengths=list()
  pathcap=list() 
  numpoints=length(txy[,1])-1
  paths[[1]]=c(numpoints+1)
  pathlengths[[1]]=0
  pathcap[[1]]=0
  j=1
  #print(txy)
  #print(numpoints)
  #start creating clusters
  for (i in 1:numpoints) {
    #print("LOL")
    #check if adding it to the path violates capacity constraints
    #also check lengthconstraint
    #print(c(paths[[j]],i,numpoints+1))
    lengthconst=pathlength(c(paths[[j]],i,numpoints+1),adjacency)<maxlength
    capconst=pathcap[[j]]+txy[i,3]<maxcap
    #print("NEW PATHCAP")
    #print(pathcap[[j]]+txy[i,3])
    if(capconst & lengthconst){
      #add vertice to path
      paths[[j]]=c(paths[[j]],i)
      #update capacity of path
      pathcap[[j]]=pathcap[[j]]+txy[i,3]
      #print("PATHCAP j")
      #print(pathcap[[j]])
      #print("IND CAP")
      #print(txy[paths[[j]],3])
      #print(paths[[j]])
      #print("SUM")
      #print(sum(txy[paths[[j]],3]))
    }else{
      #if it is not possible, then finish the original path and start a new one
      paths[[j]]=c(paths[[j]],numpoints+1)
      pathlengths[[j]]=pathlength(paths[[j]],adjacency)
      j=j+1
      paths[[j]]=c(numpoints+1,i)
      pathcap[[j]]=txy[i,3]
    }
    
    
  }
  #add tour to the depo to the last path
  paths[[j]]=c(paths[[j]],numpoints+1)
  
  
  print("PATHCAP")
  print(pathcap)
  #print("PATHLENGTH")
  #print(pathlengths)
  print(paths)
  return(paths)
  
  }
  
  
