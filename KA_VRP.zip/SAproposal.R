SAproposal=function(pathlist,numpaths, pathlengths, pathcapacity,numvertices,adjacency,p,vertexinpath,lengthconstraint,capconstraint,txy){
  ####print("PATHLENGTHS IN PROPOSAL FUN")
  ####print(pathlengths)
  ####print("NUMPATHS IN PROP FUN")
  ####print(numpaths)
  #lengthconstraint=max(pathlengths)
  source("C:\\Users\\karpatika\\Documents\\pathlength.R")
  source("C:\\Users\\karpatika\\Documents\\type1insertion.R")
  source("C:\\Users\\karpatika\\Documents\\type1inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2insertion.R")
  source("C:\\Users\\karpatika\\Documents\\remove.R")
  source("C:\\Users\\karpatika\\Documents\\pnbhd.R")
  source("C:\\Users\\karpatika\\Documents\\insert.R")
  #this function proposes a neighbouring solution from an existing one
  #there are 3 options for removal: type1 & 2 unstringing and simple remove
  t1us=FALSE
  t2us=FALSE
  rmv=FALSE
  t1s=FALSE
  t2s=FALSE
  si=FALSE
  nfif=FALSE
  #select a path to be perturbed. Longer paths have higher probability
  totallength=sum(pathlengths)
  totalcap=sum(pathcapacity)
  pathprob=(pathlengths+pathcapacity)/(totallength+totalcap)
  randompath=runif(1)
  cumpathprob=(cumsum(pathprob))
  #select modified path
  perturbedpath=min(which(cumpathprob>randompath))
#print("RANDOMPATH")
  ####print(randompath)
  ####print("compathprob")
  ####print(cumpathprob)
  ####print("PERTURBEDPATH")
  ####print(perturbedpath)
  originalpertpath=pathlist[[perturbedpath]]
  pl=length(pathlist[[perturbedpath]])
  #probabilities for removing moves
  premove=0.3
  pt1us=0.4
  pt2us=0.3
  #select removal move
  cumremoveprob=cumsum(c(premove,pt1us,pt2us))
  randommove=runif(1)
  removetool=min(which(cumremoveprob>randommove))
  #select vertex for removal
  potentialvertices=pathlist[[perturbedpath]][2:(pl-1)]
  #print("PErTPATH")
  ###print(potentialvertices)
  if(length(potentialvertices)==1){
    removevertex=potentialvertices
  }else{
    removevertex=sample(potentialvertices,1)
    
  }
  bestremovecost=99999
  ####print("REMOVEVERTEX")
  ####print(removevertex)
  #execute removal FUCK YEAH
  if(removetool==1){
            rv=match(removevertex,originalpertpath)
           newpath=remove(rv,originalpertpath)
           ####print("SIMPLE REMOVE EXECUTED")
           ####print("ORIGINALPATH")
           ####print(originalpertpath)
           ####print("REMOVEVERTEX")
           ####print(removevertex)
           ####print("NEWPATH")
           # ###print(newpath)
           rmv=TRUE
         }
         else if(removetool==2){
           #update p-nbhood of ALL vertices
           #select coordinates for type1 unstringing
           vipos=match(removevertex,originalpertpath)
           ####print("REMOVEVERTEX")
           ####print(removevertex)
           ####print("ORIGINALPATH")
           ####print(originalpertpath)
           FEASIBLE=FALSE
           try=0
           for (dolog in 1:10) {
             
           
#print("VIPOS")
             ####print(vipos)
             ####print("PL")
             ####print(pl)
           vkpos=sample((vipos+1):(pl-2),1)
           vjpos=sample((vkpos+1):(pl-1),1)
           viok=vipos<vkpos & vipos!=1
           vkok=vkpos>vipos & vkpos<vjpos
           vjok=vjpos<length(originalpertpath)
           FEASIBLE=viok&vkok&vjok
           #store best proposal
           removecost=9999
           if(try<11 & FEASIBLE){
             removecost=type1uscost(originalpertpath,vipos,vjpos,vkpos,adjacency)
              if(removecost<bestremovecost){
                bestremovecost=removecost
                besti=vipos
                bestj=vjpos
                bestk=vkpos
              }
           }
           try=try+1
           }
           if(FEASIBLE){
           newpath=type1unstringing(originalpertpath,besti,bestj,bestk)[[1]]
           ####print("TYPE 1 UNSTRINGING MOVE")
           t1us=TRUE}else{
             rv=match(removevertex,originalpertpath)
             
             newpath=remove(rv,originalpertpath)
             ###print("SIMPLE REMOVE EXECUTED SINCE TYPE 1 was NOT POSSIBLE")
             rmv=TRUE
             ####print(c("VIPOS: ",vipos))
             ####print(c("PATHLENGTH: ",pl))
           }
           
         }else if(removetool==3){
           vipos=match(removevertex,originalpertpath)
           FEASIBLE=FALSE
           try=0
           for (proba in 1:10){
             vjpos=sample((vipos+1):(pl-4),1)
             vlpos=sample((vjpos+1):(pl-3),1)
             vkpos=sample((vlpos+1):(pl-2),1)
             
             viok=vipos>1
             vjok=vjpos>vipos
             vlok=vjpos<vlpos
             vkok=vkpos>vlpos &vkpos<pl
             FEASIBLE=viok&vkok&vjok&vlok
             try=try+1
             if(FEASIBLE){
               removecost=type2uscost(originalpertpath,vipos,vjpos,vkpos,vlpos,adjacency)
               if(removecost<bestremovecost){
                 besti=vipos
                 bestj=vjpos
                 bestk=vkpos
                 bestl=vlpos
                 besremovecost=removecost
               }
           }}
           if(FEASIBLE){
           newpath=type2unstringing(originalpertpath,besti,bestj,bestk,bestl)[[1]]
           ####print("TYPE 2 UNSTRINGING MOVE")
           t2us=TRUE
####print("ORIGINAL PATH")
           ####print(originalpertpath)
           ####print("REMOVEVERTEX:")
           ####print(originalpertpath)
           ####print("NEWPATH")
           ####print(newpath)
           }else{
             rv=match(removevertex,originalpertpath)
             
             newpath=remove(rv,originalpertpath)
             ####print("SIMPLE REMOVE EXECUTED SINCE TYPE 2 was NOT POSSIBLE")
             ####print("REMOVEVERTEX: ")
             ####print(removevertex)
             ####print("ORIGINAL PATH: ")
             ####print(originalpertpath)
             rmv=TRUE
             
           }
           
         }
  #UPDATE PATHLIST
  pathlist[[perturbedpath]]=newpath
  #UPDATE VERTEX IN PATH
  vertexinpath[removevertex]=NaN
  #NOW select the move for insertion WOOHOOOO HELL YEAH
  pt1s=0.6
  pt2s=0.4
  bestinsertcost=9999
  cuminsertprob=cumsum(c(pt1s,pt2s))
  randommove=runif(1)
  inserttool=min(which(cuminsertprob>randommove))
  #select the path for insertion
  nbhood=pnbhd(removevertex,p,adjacency[-nrow(adjacency),-nrow(adjacency)])
#print("NBHOOD")
  ####print(nbhood)
  ####print("VERTEXINPATH")
  ####print(vertexinpath)
  potentialpaths=vertexinpath[nbhood]
  #exclude those which are incompatible with the length constraint using 90% of length constraint
  ####print("LENGTHCONSTRAINT IN SAPROP")
  ####print(lengthconstraint)
  potentialpaths=potentialpaths[which(pathlengths<(0.9*lengthconstraint))]
  potentialpaths=potentialpaths[which(pathcapacity+txy[removevertex,3]<(capconstraint))]
  potentialpaths=potentialpaths[which(potentialpaths!=0)]
  ####print("POTENTIALPATHS")
  ####print(potentialpaths)
  ####print("PATHLENGTHS")
  ####print(pathlengths)
  potentialpaths=potentialpaths[!is.na(potentialpaths)]
  ####print(identical(potentialpaths,numeric(0)))
  if(!identical(potentialpaths,numeric(0))){
   # ###print(length(potentialpaths))
  ####print("POTENTIALPATHS")
  ####print(potentialpaths)
  
  ipnum=sample(potentialpaths,1)
  ####print("IPNUM")
  ####print(ipnum)
  insertpath=unlist(pathlist[[ipnum]])
#print(insertpath)
  ipl=length(insertpath)
  if(inserttool==1){
           try=0
           FEASIBLE=FALSE
           for(dolog2 in 1:10){
           vipos=sample(2:(ipl-3),1)
           vjpos=sample((vipos+1):(ipl-2),1)
           vkpos=sample((vjpos+1):(ipl-1),1)
           vkok= vjpos<vkpos & vkpos<ipl
           vivjok=vipos<vjpos & 1<vipos & vjpos<ipl
           #check the condition that this is indeed a type 1 insertion
           type1ok= vkpos!=vipos & vkpos!=vjpos
           FEASIBLE=vkok&vivjok&type1ok
           try=try+1
           insertcost=999
           if(FEASIBLE){
             insertcost=type1inscost(insertpath,removevertex,vipos,vjpos,vkpos,adjacency = adjacency)
             if(insertcost<bestinsertcost){
               bestinsertcost=insertcost
               besti=vipos
               bestj=vjpos
               bestk=vkpos
               
             }
           }}
           if(FEASIBLE){
             newinsertpath=type1insertion(removevertex,insertpath,besti,bestj,bestk)
             t1s=TRUE
#print("TYPE 1 INSERTION MOVE")
             ###print("ORIGINAL PATH: ")
             ###print(insertpath)
             ####print(c("REMOVEVERTEX","VIPOS","VJPOS","VKPOS"))
             ####print(c(removevertex,vipos,vjpos,vkpos))
             ####print(c("VI","VJ","VK"))
             ####print(c(insertpath[vipos],insertpath[vjpos],insertpath[vkpos]))
             ###print("AFTER INSERTION: ")
             ###print(newinsertpath)
           }else{
#print("NO FEASIBLE T1 INSERTION FOUND, INSERTING AFTER CLOSES NEIGHBOUR")
             #find closest nbh
             ####print(insertpath)
             ####print(c("INSERTVERTEX: ",removevertex))
             closestnb=insertpath[pnbhd(removevertex,1,adjacency[,insertpath])]
             ####print("CLOSEST NEIGHBOUR FOUND")
             ####print(insertpath)
             ####print(closestnb)
             pcn=match(closestnb,insertpath)+1
             ####print("PCN")
             ####print(pcn)
             newinsertpath=insert(insertpath,removevertex,pcn)
#print("NEWINSERTPATH")
             ####print(newinsertpath)
             si=TRUE
             #pathlist[[perturbedpath]]=originalpertpath
           }
         }else if(inserttool==2){
           try=0
           FEASIBLE=FALSE
           for (prob1 in 1:10) {
             vipos=sample(2:(ipl-4),1)
             vlpos=sample((vipos+1):(ipl-3),1)
             vjpos=sample((vlpos+1):(ipl-2),1)
             vkpos=sample((vjpos+1):(ipl-1),1)
             
             vivjok=vipos<vjpos
             vkok=vkpos!=vjpos & vkpos!=(vjpos+1) & vkpos>vjpos
             vlok=vlpos!=vipos & vlpos!=(vipos+1) & vlpos>vipos & vlpos<vjpos
             FEASIBLE=vkok&vivjok&vlok
             try=try+1
             if(FEASIBLE){
               insertcost=type2inscost(insertpath,removevertex,vipos,vjpos,vkpos,vlpos,adjacency)
               if(insertcost<bestinsertcost){
                 besti=vipos
                 bestj=vjpos
                 bestk=vkpos
                 bestl=vlpos
                 bestinsertcost=insertcost
               }
             }}
           if(FEASIBLE){
             newinsertpath=type2insertion(removevertex,insertpath,besti,bestj,bestk,bestl)
             t2s=TRUE
#print("TYPE 2 INSERTION MOVE")
             ####print(c("REMOVEVERTEX","VIPOS","VJPOS","VKPOS","VLPOS"))
             ####print(c(removevertex,vipos,vjpos,vkpos,vlpos))
             ####print(c("VI","VJ","VK","VL"))
             ####print(c(insertpath[vipos],insertpath[vjpos],insertpath[vkpos],insertpath[vlpos]))
           }else{
             ####print("NO FEASIBLE T2 INSERTION FOUND, INSERTING AFTER CLOSEST NEIGHBOUR")
             ####print(insertpath)
             
             ####print(adjacency[removevertex,insertpath])
             ####print("LOL1")
             cucc=which(adjacency[removevertex,]==min(adjacency[removevertex,insertpath]))
             ####print(cucc)
             ####print(typeof(cucc))
             ####print("LOL")
             closestnb=cucc
#print("REMOVEVERTEX")
             ####print(removevertex)
             ####print(closestnb)
             pcn=match(closestnb,insertpath)+1
             newinsertpath=insert(insertpath,removevertex,pcn)
             si=TRUE
             #pathlist[[perturbedpath]]=originalpertpath
           }
           
           
         }
#print("UPDATING PATHLIST")
  #if(t1s |t2s |si){
  if(TRUE){
  pathlist[[ipnum]]=newinsertpath
  ####print("PATHLIST UPDATED")
  }
  }else{
    ####print("NO FEASIBLE INSERTION FOUND")
    nfif=TRUE
    pathlist[[perturbedpath]]=originalpertpath
  }
#print("change")
  ####print(pathlist[[perturbedpath]])
  ####print(originalpertpath)
  return(pathlist)
}