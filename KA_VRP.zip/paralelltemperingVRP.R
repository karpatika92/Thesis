ParallelTemperingVRP=function(numvertices,pathlist,adjacency,maxiter=1000,maxtemp=100,mintemp=1,lengthconstraint,txy,maxcapacity,templevels,graphics=FALSE){
  
  
  #pathlist is an initial solution to the problem
  #the program expects this to be a list of vectors, where the first and the last element of each vector is the depot
  #first calculate the cost of the initial solution
  source("C:\\Users\\karpatika\\Documents\\pathlength.R")
  source("C:\\Users\\karpatika\\Documents\\coolingfunction.R")
  source("C:\\Users\\karpatika\\Documents\\3_opt.R")
  source("C:\\Users\\karpatika\\Documents\\type1insertion.R")
  source("C:\\Users\\karpatika\\Documents\\type1inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2insertion.R")
  source("C:\\Users\\karpatika\\Documents\\remove.R")
  source("C:\\Users\\karpatika\\Documents\\pnbhd.R")
  source("C:\\Users\\karpatika\\Documents\\GENItsp.R")
  source("C:\\Users\\karpatika\\Documents\\USTSP.R")
  source("C:\\Users\\karpatika\\Documents\\SAproposal.R")
  source("C:\\Users\\karpatika\\Documents\\SAobjfun.R")
  source("C:\\Users\\karpatika\\Documents\\consistencycheck.R")
  require(stats)
  #CHECK INITIAL SOLUTION
  consistencycheck(pathlist)
  ##  Open a new default device.
  if(graphics){
  get( getOption( "device" ) )()
  

  par( mfcol = c( 2, templevels ) )}
  #create necessary statistics of solution
  objfunvector= matrix(rep(0,maxiter*templevels),nrow=templevels,ncol=maxiter)
  temperature=rep(0,templevels)
  #initiating templevels
  #assuming linear schedule
  stateswaps=0
  accss=0
  noaccss=0
  msf=rep(0,templevels)
  
  ornumpaths=rep(length(pathlist),templevels)
  numpaths=ornumpaths
  for(i in 1:templevels){
    temperature[i]=coolingfunction(maxtemp=maxtemp,mintemp=mintemp,maxiter=templevels,iter=i,shape="linear")
  }
  ###print(temperature)
  
  #CREATE SUPERPATHLIST
  superpathlist=list()
  for(i in 1:templevels){
    superpathlist[[i]]=pathlist
  }
  #historical temperature is necessary for temperature adjustment
  histtemp=array(0,dim=c(templevels,ornumpaths[1],maxiter))
  histpathlengths=array(0,dim=c(templevels,ornumpaths[1],maxiter))
  pathlengths=list()
  pathcap=list()
  pathlengths2=list()
  vertexinpath=list()
  #FILL THE ABOVE EMPTY LISTS WITH ZEROES
  for (i in 1:templevels) {
    #consistencycheck(pathlist)
      pathlengths[[i]]=rep(0,ornumpaths[1])
      pathlengths2[[i]]=rep(0,ornumpaths[1])
      pathcap[[i]]=rep(0,ornumpaths[1])
      vertexinpath[[i]]=rep(0,numvertices)
    
  }
  nfif=rep(0,templevels)
  acceptmove=rep(0,templevels)
  worsemoves=rep(0,templevels)
  bettermoves=rep(0,templevels)
  wamoves=rep(0,templevels)
  msa=rep(0,templevels)
  noaccept=rep(0,templevels)
  iter=1
  nbs=rep(0,templevels)
  nbstep=rep(0,templevels)
  bestpath=pathlist
  p=10
  bestfeasiblepath=pathlist
  bestf1cost=SAobjfun(pathlist,adjacency)
  for (SA in 1:templevels) {
    #print(c("ITERATION: ",iter))
    #print(superpathlist[[SA]])
    #update numpaths,pathlengths, pathlengths2, pathcapacity, vertexinpath and objective function
    objfunvector[SA,iter]=SAobjfun(superpathlist[[SA]],adjacency)
    #FEASABILITYCHECK
    fsbl=feasabilitycheck(superpathlist[[SA]],lengthconstraint,maxcapacity,adjacency,txy)
    if(fsbl==1){
      msf[SA]=0
      if(SAobjfun(superpathlist[[SA]],adjacency)<bestf1cost){
        bestfeasiblepath=superpathlist[[SA]]
        bestf1cost=SAobjfun(superpathlist[[SA]],adjacency)
        
      }
    }else{
      msf[SA]=msf[SA]+1
      #print("MSF")
      #print(c(msf[SA]," in",maxiter/3))
    }
    if(msf[SA]>(maxiter/8)){
      superpathlist[[SA]]=bestfeasiblepath
    }
       ###print("SA1")
    ###print(SA)
    
    for(i in 1:numpaths[[SA]]){
      ###print("SA2")
      ###print(SA)
      
      pathlengths2[[SA]][i]=length(superpathlist[[SA]][[i]])
      ###print("SA3")
      ###print(SA)
      pathlengths[[SA]][i]=pathlength(superpathlist[[SA]][[i]],adjacency)
      #print("SA4")
      ###print(SA)
      
      pathcap[[SA]][i]=sum(txy[superpathlist[[SA]][[i]],3 ])
      
      for(j in 1:pathlengths2[[SA]][i]){
        vertexinpath[[SA]][superpathlist[[SA]][[i]][j]]=i
        ###print("SA")
        ###print(SA)
      }
    }
  }
  
  
  initialcost=sum(pathlengths[[1]])
  currentcost=rep(initialcost,templevels)
  bestcost=rep(initialcost,templevels)
  
  for (iter in 1:maxiter) {
    print(c("PT ITERATION: ",iter," IN ",maxiter))
    
    
    #update graphics if iter is divisible by 50 and at first iteration
    if((iter==1 |iter%%10==0)&graphics){
      for (SA in 1:templevels) {
        plot( objfunvector[SA,], col = "blue",ylim=c(0,max(objfunvector)),main = c("OBJFUN @ TEMP",temperature[SA]), cex.lab = 1.1 ,type = "l")
        plot(0,0,xlim = c(1,maxiter),ylim = c(0,2*lengthconstraint),type = "l")
        
        cl <- rainbow(ornumpaths)
        
        for (i in 1:ornumpaths[SA]){
          lines(1:maxiter,histpathlengths[SA,i,],col = cl[i],type = 'l')
        }
      }
    }
  #DO parallel tempering for each temperature level
    for (SA in 1:templevels) {
      #print(c("ITERATION: ",iter))
      #update numpaths pathlengths, pathlengths2, pathcapacity, vertexinpath and objective function
      #print("SA")
      #print(SA)
      
      #FEASABILITYCHECK
      fsbl=feasabilitycheck(superpathlist[[SA]],lengthconstraint,maxcapacity,adjacency,txy)
      if(fsbl==1){
        msf[SA]=0
        if(SAobjfun(superpathlist[[SA]],adjacency)<bestf1cost){
          bestfeasiblepath=superpathlist[[SA]]
          bestf1cost=SAobjfun(superpathlist[[SA]],adjacency)
          
        }
      }else{
        msf[SA]=msf[SA]+1
        print("MSF")
        print(c(msf[SA]," in",maxiter/20))
      }
      print(msf[SA]>(maxiter/20))
      if(msf[SA]>(maxiter/20)){
        #TRY USTSP
        print("USTSP TRYING TO MAKE IT FEASIBLE")
        tempnumpaths=length(superpathlist[[SA]])
        for (i in 1:tempnumpaths) {
          superpathlist[[SA]][[i]]=USTSP(superpathlist[[SA]][[i]],adjacency,p=5,steps=length(superpathlist[[SA]][[i]]))
        }
        fsbl2=feasabilitycheck(superpathlist[[SA]],lengthconstraint,maxcapacity,adjacency,txy)
        if(fsbl2!=1){
          print("NOOOOOO COULDNT MAKE IT FEASIBLE")
          superpathlist[[SA]]=bestfeasiblepath
          msf[SA]=0
      }else{
        print("!!!!!!!!!!!!!COULD MAKE IT FEASIBLE!!!!!!!!!!!!!!!!4")
        msf[SA]=0
        if(SAobjfun(superpathlist[[SA]],adjacency)<bestf1cost){
          bestfeasiblepath=superpathlist[[SA]]
          bestf1cost=SAobjfun(superpathlist[[SA]],adjacency)
          
        }
        
        
        }}
      numpaths[[SA]]=length(superpathlist[[SA]])
      #print("SUPERPATHLIST")
      #print(superpathlist[[SA]])
      objfunvector[SA,iter]=SAobjfun(superpathlist[[SA]],adjacency)
      #print("LOL")
      pathlengths2[[SA]]=sapply(superpathlist[[SA]],length)
      for(i in 1:numpaths[[SA]]){
      pathlengths[[SA]][i]=pathlength(superpathlist[[SA]][[i]],adjacency)
      pathcap[[SA]][i]=sum(txy[superpathlist[[SA]][[i]],3 ])
        for(j in 1:pathlengths2[[SA]][[i]]){
        vertexinpath[[SA]][superpathlist[[SA]][[i]][j]]=i
        }
      }
      histpathlengths[SA,,iter]=pathlengths[[SA]]
      
      #STATS UPDATED
      #NOW THE MCMC STEP
      #decide if swap or pathlist update
      probb=runif(1)
      #♥##print("PROBB")
      ###print(probb)
      if(probb>0.3 ){
        for (i in 1:templevels) {
          #print("NORMAL SA STEP ATTEMPTED")
          ###print(superpathlist[[i]])
          lol=superpathlist[[i]]
          superpathlist[[i]]=SimulatedAnnealingVRP(numvertices,superpathlist[[i]],adjacency,schedule="linear",maxiter=1,maxtemp=temperature[i],mintemp = temperature[i],lengthconstraint = lengthconstraint,txy = txy,maxcapacity = maxcapacity,graphics=FALSE)[[2]]
          ##print("NORMAL SA STEP")
          if(SAobjfun(lol,adjacency)<SAobjfun(superpathlist[[i]],adjacency)){
            ##print("SHIT MOVE WAS OK ENOUGH")
            acceptmove[i]=acceptmove[i]+1
            worsemoves[i]=worsemoves[i]+1
            
            
          }else if(SAobjfun(lol,adjacency)==SAobjfun(superpathlist[[i]],adjacency)){
            nfif[i]=nfif[i]+1
            
          }
          else{
            ##print("MEH LOCAL IMPROVEMENT")
            bettermoves[i]=bettermoves[i]+1
            acceptmove[i]=acceptmove[i]+1
          }
        
          #check if search went too far
          numpaths=length(superpathlist[[i]])
          for(j in 1: numpaths){
          pathlengths[[i]][j]=pathlength(superpathlist[[i]][[j]],adjacency)}
          if(max(pathlengths[[i]])>lengthconstraint*2){
            superpathlist[[i]]=bestpath
          }
        }
      }else{
        #SWAP 2 STATES
        states=sample(1:templevels,2,replace = FALSE)
        #check corresponging temperatures and objective functions
        if((objfunvector[states[1],iter]>objfunvector[states[2],iter])==(temperature[states[1]]<temperature[states[2]])){
          templist=superpathlist[[states[1]]]
          superpathlist[[states[1]]]=superpathlist[[states[2]]]
          superpathlist[[states[2]]]=templist
          #print("STATES SWITCHED")
          ##print("STATE 1 & 2")
          ##print(states)
          stateswaps=stateswaps+1
          accss=accss+1
        }else{
        accprob=min(1,exp((objfunvector[states[1],iter]-objfunvector[states[2],iter])*(1/temperature[states[1]]-1/temperature[states[2]])))
        probbb=runif(1)
        if(accprob>probb){
          templist=superpathlist[[states[1]]]
          superpathlist[[states[1]]]=superpathlist[[states[2]]]
          superpathlist[[states[2]]]=templist
          ##print("STATES SWITCHED")
          ##print("ACCPROB PT")
          ##print(accprob)
          ##print("PROBB PT")
          ##print(probbb)
          stateswaps=stateswaps+1
          accss=accss+1

        }else{
          ##print("STATE SWAP NOT ACCEPTED")
          noaccss=noaccss+1
        }}
      }
    }
    #DELETE EMPTY PATHS
    #UPDATE PATHLENGTHS2
    for (SA in 1:templevels) {
      numpaths[SA]=length(superpathlist[[SA]])
      for (s in 1:numpaths[SA]) {
        pathlengths2[[SA]][s]=length(superpathlist[[SA]][[s]])
      }
    
    if(length(which(pathlengths2[[SA]]<3)>0)){
    superpathlist[[SA]][[which(pathlengths2[[SA]]<3)]]=NULL}}
    for (SA in 1:templevels) {
      ##print(c("ITERATION: ",iter))
      #update numpaths pathlengths, pathlengths2, pathcapacity, vertexinpath and objective function
      numpaths[[SA]]=length(superpathlist[[SA]])
      objfunvector[SA,iter]=SAobjfun(superpathlist[[SA]],adjacency)
      pathlengths2[[SA]]=sapply(superpathlist[[SA]],length)
      for(i in 1:numpaths[[SA]]){
        pathlengths[[SA]][i]=pathlength(superpathlist[[SA]][[i]],adjacency)
        pathcap[[SA]][i]=sum(txy[superpathlist[[SA]][[i]],3 ])
        for(j in 1:pathlengths2[[SA]][[i]]){
          vertexinpath[[SA]][superpathlist[[SA]][[i]][j]]=i
        }
      }
    }
    #NOW THAT ALL STATES HAVE BEEN UPDATED, CHECK IF WE FOUND A NEW BEST SOLUTION
    #calculate objective function for each solution
    for(SA in 1:templevels){
      
    objfunvector[SA,iter]=SAobjfun(superpathlist[[SA]],adjacency)
    #print("OBJFUN CALCULATED, SUPERPATHLIST")
    #print(superpathlist[[SA]])
    consistencycheck(superpathlist[[SA]])
    }
    #find minimum
    #check variance of each temperature level
    objfunvar=rep(0,templevels)
    targetvar=seq(from=0.2,to=0.05,length.out=templevels)
    if(iter%%20==0){
      for(SA in 1:templevels){
        objfunvar[SA]=var(objfunvector[SA,(iter-19):iter])/mean(objfunvector[SA,(iter-19):iter])
        #also check if chain is stuck, if it is give it the best solution so far
        if(objfunvar[SA]==0 & iter%%60==0){
          superpathlist[[SA]]=bestpath
          #print(superpathlist[[SA]])
        }
        #print("OBJFUNVAR")
        ###print(objfunvar)
        ###print("VAR")
        ###print(var(objfunvector[SA,1:iter]))
        #print("MEAN")
        ###print(mean(objfunvector[SA,1:iter]))
                          if(objfunvar[SA]>(targetvar[SA]*1.1)){
                            temperature[SA]=max(0.1,temperature[SA]/1.1)
                          
        
                          }else if(objfunvar[SA]<(targetvar[SA]/1.1)){
        temperature[SA]=temperature[SA]*1.1
                          }
      }
    }
    currentbestcost=min(objfunvector[,iter])
    if(currentbestcost<bestcost){
       #find minimum
      bestloc=which(objfunvector[,iter]==currentbestcost)
      bestcost=currentbestcost
      bestpath=superpathlist[[bestloc]]
    }
  }
  #print("DIAGNOSTICS")
  #print("STATESWAPS / ACCEPTED / NOT")
  #print(c(stateswaps,accss,noaccss))
  #print("SA MOVES ACCEPTED / WORSE ACCEPTED / BETTER MOVES /NFIF / NOT ACCEPTED")
  #print(c(acceptmove,wamoves,bettermoves,nfif))
  return(bestfeasiblepath)
}