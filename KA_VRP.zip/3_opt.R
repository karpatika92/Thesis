threeopt=function(path,adjacency){
  source("C:\\Users\\karpatika\\Documents\\pathlength.R")
  #3 nested for cycles to cycle through every permutation
  numvertice=length(path)
  if(numvertice>4){
  perm=list()
  for (i in 2:(numvertice-3)) {
    for (j in (i+1):(numvertice-2)) {
      for (k in (j+1):(numvertice-1)) {
        perm[[1]]=c(i,k,j)
        perm[[2]]=c(j,i,k)
        perm[[3]]=c(j,k,i)
        perm[[4]]=c(k,i,j)
        perm[[5]]=c(k,j,i)
        #create every possible permutation for the selected 3 vertices
        newroute=list()
        newlength=c(rep(0,5))
        for (p in 1:5) {
          newroute[[p]]=replace(path,c(i,j,k),path[perm[[p]]])
          newlength[p]=pathlength(newroute[[p]],adjacency)
          bestnewroute=which.min(newlength)}
          if( pathlength(newroute[[bestnewroute]],adjacency) < pathlength(path,adjacency) ) {
            path=newroute[[bestnewroute]]
            #print("3-opt found a better permutation: ")
            #print(c(i,j,k))
            #print(perm[[p]])
            #print("New path length: ")
            #print(pathlength(path,adjacency))
            
          } 
        
        
      }
    }
  }
  }
  return(path)
  
}