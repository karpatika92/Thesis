SEARCHVRP=function(pathlist,numvertices,vertexinpath,W,q=5,p1=5,p2=5,thetamin=1,thetamax=10,g=0.005,h,nmax,adjacency,lengthconstraint,capacityconstraint,txy){
  source("C:\\Users\\karpatika\\Documents\\pathlength.R")
  source("C:\\Users\\karpatika\\Documents\\coolingfunction.R")
  source("C:\\Users\\karpatika\\Documents\\3_opt.R")
  source("C:\\Users\\karpatika\\Documents\\type1insertion.R")
  source("C:\\Users\\karpatika\\Documents\\type1inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type1unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2uscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2unstringing.R")
  source("C:\\Users\\karpatika\\Documents\\type2inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2insertion.R")
  source("C:\\Users\\karpatika\\Documents\\remove.R")
  source("C:\\Users\\karpatika\\Documents\\pnbhd.R")
  source("C:\\Users\\karpatika\\Documents\\GENItsp.R")
  source("C:\\Users\\karpatika\\Documents\\USTSP.R")
  source("C:\\Users\\karpatika\\Documents\\SAproposal.R")
  source("C:\\Users\\karpatika\\Documents\\SAobjfun.R")
  source("C:\\Users\\karpatika\\Documents\\consistencycheck.R")
  source("C:\\Users\\karpatika\\Documents\\f2VRP.R")
  source("C:\\Users\\karpatika\\Documents\\feasabilitycheck.R")
  require(stats)
  get( getOption( "device" ) )()
  
  orgq=q
  par( mfrow = c( 1, 2 ) )
  objfunvar=0
  #CHECK INITIAL SOLUTION
  consistencycheck(pathlist)
  iter=1
  fv=rep(0,numvertices)
  deltamax=1
  bestfeasiblesolution=pathlist
  bestunfeasiblesolution=pathlist
  alphapm=10
  betapm=10
  tabulist=list()
  bestf1=SAobjfun(pathlist,adjacency)
  histf1=rep(NaN,nmax)
  histf2=rep(NaN,nmax)
  cond2=c(TRUE,FALSE)
  bestf2=bestf1
  bf1step=0
  bf2step=0
  ##print("LOL")
  bestf2=F2objfun(pathlist,alphapm,betapm,lengthconstraint,capacityconstraint,adjacency,txy)
  varcondition=TRUE
  lastUSuse=0
  #print((((iter-bf1step)>nmax) & ((iter-bf2step)>nmax))|iter>100 | !varcondition)
  while(!(  ((iter-bf1step)>nmax) & ((iter-bf2step)>nmax)|iter>100 | !varcondition)) {
    q=orgq
    consistencycheck(pathlist)
    numpaths=length(pathlist)
    m=numpaths
    vertexinpath=rep(0,numvertices)
    
    pathlengths2=rep(0,numpaths)
    ##DELETE EMPTY PATHS
    for (pth in 1:numpaths) {
      pathlengths2[pth]=length(pathlist[[pth]])
    }
    
    cucc=which(pathlengths2==2)
    if(length(cucc)>0){
      
      pathlist[[cucc]]=NULL
      print("PATH DELETED")
    }
    consistencycheck(pathlist)
    numpaths=length(pathlist)
    
    for (pth in 1:numpaths) {
      pathlengths2[pth]=length(pathlist[[pth]])
    }
    
    for (i in 1:numpaths) {
      for (j in 2:(pathlengths2[i]-1)) {
        vertexinpath[pathlist[[i]][j]]=i
      }
    }
    #move lone vertex if possible
    if(min(pathlengths2)==3){
      pth=min(which(pathlengths2==2))
      movevertices=pathlist[[pth]][2]
      q=1
    }    
    
    bestinsertpathnum=rep(0,q)
    consistencycheck(pathlist)
    #print(c("TR ITER: ",iter))
     bestt1jrmv=rep(0,q)
    bestt1irmv=rep(0,q)
    bestt1krmv=rep(0,q)
    rmvtype=rep(0,q)
    bestt2jrmv=rep(0,q)
    bestt2irmv=rep(0,q)
    bestt2krmv=rep(0,q)
    bestt2lrmv=rep(0,q)
    perturbedpathnum=rep(0,q)
    instype=rep(0,q)
    bestt1i=rep(0,q)
    bestt1j=rep(0,q)
    bestt1k=rep(0,q)
    bestt2i=rep(0,q)
    bestt2j=rep(0,q)
    bestt2k=rep(0,q)
    bestt2l=rep(0,q)
    bestremovecost=rep(9999,q)
    bestt1removecost=rep(9999,q)
    bestt2removecost=rep(9999,q)
    bestinsertcost=rep(9999,q)
    bestt1insertcost=rep(9999,q)
    bestt2insertcost=rep(9999,q)
    
    #print("WHILE DONE")
    #print(histf1)
    #print(histf2)
    #RANDOMLY SELECT q cities from W
  movevertices=sample(W,q,replace=FALSE)
  consistencycheck(pathlist)
  numpaths=length(pathlist)
  m=numpaths
  perturbedpath=list()
  bestinsertpath=list()
  newperturbedpath=list()
  #UPDATE VERTEXINPATH

  #EVALUATION OF ALL CANDIDATE MOVES
  for (v in 1:q) {
    print("CYCLE STRTED")
    print(c("V: ",v))
    movevertice=movevertices[v]
    #print("MOVEVERTICEV")
    #print(movevertices[v])
    #print("VERTEXINPATH")
    #print(vertexinpath)
    #get route of movevertice
    perturbedpathnum[v]=vertexinpath[movevertice]
    #print("PPPNUM")
    #print(perturbedpathnum[v])
    #print("PATHLIST")
    #print(pathlist)
    perturbedpath[[v]]=pathlist[[perturbedpathnum[v]]]
    ##print("PP")
    ##print(perturbedpath[[v]])
    #get vipos
    vipos=match(movevertice,perturbedpath[[v]])
    #check all possible remove options type1 and type2
    pplength=length(perturbedpath[[v]])
    
    ##print("VARIABLE SETUP OK")
    #search for typ1 removals
    ##print("VIPOS")
    ##print(vipos)
    ##print("PPLENGTH")
    ##print(pplength)
    for (vkpos in (vipos+1):(pplength-1)) {
      ##print("VKPOS")
      ##print(vkpos)
      for (vjpos in (vkpos+1):(pplength)) {
        ##print("VJPOS")
        ##print(vjpos)
        #calculate remove cost
        removecostt1=type1uscost(perturbedpath[[v]],vipos,vjpos,vkpos,adjacency)
        if(removecostt1<bestt1removecost[v]){
          bestt1removecost[v]=removecostt1
          bestt1jrmv[v]=vjpos
          bestt1krmv[v]=vkpos
          bestt1irmv[v]=vipos
          if(removecostt1<bestremovecost[v]){
            bestremovecost[v]=removecostt1
            rmvtype[v]=1
          }
        }
      }
      
    }
    #search for type 2 removals
    for (vjpos in (vipos+1):(pplength-2)) {
      for (vlpos in (vjpos+1):(pplength-1)){
        for(vkpos in (vlpos+1):pplength){
          removecostt2=type2uscost(perturbedpath[[v]],vipos,vjpos,vkpos,vlpos,adjacency)
          if(removecostt2<bestt2removecost[v]){
            bestt2removecost[v]=removecostt2
            bestt2irmv[v]=vipos
            bestt2jrmv[v]=vjpos
            bestt2krmv[v]=vkpos
            bestt2lrmv[v]=vlpos
            if(removecostt2<bestremovecost[v]){
              bestremovecost[v]=removecostt2
              rmvtype[v]=2
            }
          }
        }
      }
    }
    #if type is 0 stop with error
    if(rmvtype[v]==0){
      #print("NO FEASIBLE REMOVAL WHICH IS STRANGE")
      ##print(perturbedpath[[v]])
      ##print("PPLENGTH")
      ##print(pplength)
      ##print("REMOVEVERTEX")
      ##print(perturbedpath[[v]][vipos])
      ##print(movevertices[v])
      newperturbedpath[[v]]=remove(vipos,perturbedpath[[v]])
      bestremovecost[v]=pathlength(perturbedpath[[v]],adjacency)-pathlength(newperturbedpath[[v]],adjacency)
    }else if(rmvtype[v]==1){
      #print("Type 1 unstringing")
      #print(c("i","j","k"))
      #print(c(bestt1irmv[v],bestt1jrmv[v],bestt1krmv[v]))
      
      ##print("BEST remove cost T1")
      ##print(bestt1removecost)
      ##print("T2")
      ##print(bestt2removecost)
      ##print("RMVTYPE")
      ##print(rmvtype)
      ##print("V")
      ##print(v)
      newperturbedpath[[v]]=type1unstringing(perturbedpath[[v]],bestt1irmv[v],bestt1jrmv[v],bestt1krmv[v])[[1]]
    }else if(rmvtype[v]==2){
      #print("Type 2 unstringing")
      #print(c("i","j","k","l"))
      #print(c(bestt2irmv[v],bestt2jrmv[v],bestt2krmv[v],bestt2lrmv[v]))
      #print("BEST remove cost T1")
      #print(bestt1removecost)
      #print("T2")
      #print(bestt2removecost)
      newperturbedpath[[v]]=type2unstringing(perturbedpath[[v]],bestt2irmv[v],bestt2jrmv[v],bestt2krmv[v],bestt2lrmv[v])[[1]]
    }
    #now that the removal has been executed continue with STEP2
    #now find best insertion to routes using GENI
    #get p2-nbhood of all vertices
    nbhoodp1=list()
    nbhoodp2=list()
    #print("LOL1")
    for (i in 1:numvertices) {
      ##print("LOL1")
      nbhoodp1[[i]]=pnbhd(i,p1,adjacency[-nrow(adjacency),-ncol(adjacency)])
      nbhoodp2[[i]]=pnbhd(i,p2,adjacency[-nrow(adjacency),-ncol(adjacency)])
      
    }
    #print("LOL2")
    #get potential paths
    potentialpaths=vertexinpath[nbhoodp1[[movevertice]]]
    ##print("POTPATHS1")
    ##print(potentialpaths)
    potentialpaths=unique(potentialpaths)
    #remove original path from potential paths
    ##print("POTPATHS1")
    ##print(potentialpaths)
    ##print("ORIGINAL PATH")
    ##print(perturbedpathnum[[v]])
    ##print(which(potentialpaths==perturbedpathnum[[v]]))
    dolog=which(potentialpaths==perturbedpathnum[[v]])
    potentialpaths=potentialpaths[-dolog]
    print("POTPATHS2")
    print(potentialpaths)
    numpotpaths=length(potentialpaths)
    #FIND BEST INSERTPATH
    ##print("NUMPOTPATHS")
    ##print(numpotpaths)
    #print("POTPATHS")
    #print(potentialpaths)
    ##print("LOL2.5")
    if(numpotpaths==0){
      if(perturbedpathnum[[v]]!=1){
      potentialpaths=c(1)}else{potentialpaths=c(2)}
      numpotpaths=1
    }
    for (pth in 1:numpotpaths) {
      insertpath=pathlist[[potentialpaths[pth]]]
      #get type1 insertion costs
      options=min(p2,length(insertpath)-1)
      #get p2 closest vertices in the path
      #print("pth")
      #print(pth)
      ##print(adjacency[insertpath,])
      ##print(pnbhd(movevertice,p2,adjacency[,insertpath]))
      nbhdv=insertpath[pnbhd(movevertice,p2,adjacency[,insertpath])]
      ##print("NBHDV")
      ##print(nbhdv)
      #find best t1 insertion for actual insertpath
      #print("LOL3")
      for (i in 1:options) {
        for (j in 1:options) {
          vi=nbhdv[i]
          vj=nbhdv[j]
          vipos=match(vi,insertpath)
          vjpos=match(vj,insertpath)
          ##print("VI")
          ##print(vi)
          ##print("VIPOS")
          ##print(vipos)
          ##print("VJPOS")
          ##print(vjpos)
          vip1=insertpath[vipos+1]
          ##print("LOL3")
          ##print("VIP1")
          ##print(vip1)
          ##print("INSERTPATH")
          ##print(insertpath)
          nbhdvip1=insertpath[pnbhd(vip1,p2,adjacency[,insertpath])]
          for (k in 1:options) {
            vk=nbhdvip1[k]
            vkpos=match(vk,insertpath)
            #now calculate insertion cost
            t1insertcost=type1inscost(insertpath,movevertice,vipos,vjpos,vkpos,adjacency)
            if(t1insertcost<bestt1insertcost[v]){
              bestt1insertcost[v]=t1insertcost
              bestt1i[v]=vipos
              bestt1j[v]=vjpos
              bestt1k[v]=vkpos
              if(t1insertcost<bestinsertcost[v]){
                bestinsertpath[[v]]=insertpath
                bestinsertpathnum[v]=potentialpaths[pth]
                bestinsertcost[v]=t1insertcost
                instype[v]=1}
          }
        }
        }
      }
      #find best t2 insertion for actual insertpath
      #print("LOL4")
      for (i in 1:options) {
        vi=nbhdv[i]
        vipos=match(vi,insertpath)
        for (j in 1:options) {
          vj=nbhdv[j]
          vjpos=match(vj,insertpath)
          for (k in 1:options) {
            ##print("LOL4")
            nbhdvip1=insertpath[pnbhd(vi,p2,adjacency[,insertpath])]
            vk=nbhdvip1[k]
            vkpos=match(vk,insertpath)
            for (l in 1:options) {
              ##print("LOL5")
              nbhdvjp1=insertpath[pnbhd(vj,p2,adjacency[,insertpath])]
              vl=nbhdvjp1[l]
              vlpos=match(vl,insertpath)
              #calculate t2 insertcost
              t2insertcost=type2inscost(insertpath,movevertice,vipos,vjpos,vkpos,vlpos,adjacency)
              ##print("COST CALCULATED, L OPTIONS")
              ##print(c(l,options))
              if(t2insertcost<bestt2insertcost[v]){
                bestt2insertcost[v]=t2insertcost
                bestt2i[v]=vipos
                bestt2j[v]=vjpos
                bestt2k[v]=vkpos
                bestt2l[v]=vlpos
                if(t2insertcost<bestinsertcost[v]){
                  bestinsertpath[[v]]=insertpath
                  bestinsertpathnum[v]=potentialpaths[pth]
                  bestinsertcost[v]=t2insertcost
                  instype[v]=2
                }
              }
            }
          }
        }
      }
    }
    #if type is 0 stop with error
    ##print("INSTYPE")
    ##print(instype)
    if(instype[v]==0){
      print("NO FEASIBLE INSERTION WHICH IS STRANGE")
      #newperturbedpath[[v]]=remove(vipos,perturbedpath)
    }else if(instype[v]==1){
      ##print("V")
      ##print(v)
      print("Type 1 INSERTION")
      print(c("i","j","k"))
      #print(c(bestt1i[v],bestt1j[v],bestt1k[v]))
      
      print("BEST INSERTION cost T1")
      print(bestt1insertcost)
      print("T2")
      print(bestt2insertcost)
      print("RMVTYPE")
      print(rmvtype)
      ##print("V")
      ##print(v)
      #newperturbedpath[[v]]=type1unstringing(perturbedpath[[v]],bestt1irmv[v],bestt1jrmv[v],bestt1krmv[v])[[1]]
    }else if(instype[v]==2){
      print("Type 2 INSERTION")
      print(c("i","j","k","l"))
      print(c(bestt2i[v],bestt2j[v],bestt2k[v],bestt2l[v]))
      print("BEST INSERT cost T1")
      print(bestt1insertcost)
      print("T2")
      print(bestt2insertcost)
      #newperturbedpath[[v]]=type2unstringing(perturbedpath[[v]],bestt2irmv[v],bestt2jrmv[v],bestt2krmv[v],bestt2lrmv[v])[[1]]
    }
    
  }
  
  #now that all insertions for all moveable vertices have been calculated, consider the 
  #ULTIMATE BEST MOVE BIATCH
  mdf1objfun=rep(0,q)
  mdf2objfun=rep(0,q)
  ##print("RMVTYPE B4 TMPSOL")
  ##print(rmvtype)
  ##print("BEST MOVES")
  ##print("INSERTION")
  ##print(c(bestt1i,bestt1j,bestt1k))
  ##print(c(bestt2i,bestt2j,bestt2k,bestt2l))
  ##print("REMOVAL")
  ##print(c(bestt1irmv,bestt1jrmv,bestt1krmv))
  #print(c(bestt2irmv,bestt2jrmv,bestt2krmv,bestt2lrmv))
  #REMOVING TABU MOVES
  qvec=1:q
  numtabus=length(tabulist)
  a=0
  tbd=c()
  if(numtabus>0){
  for (v in 1:q) {
     for (i in 1:numtabus) {
       if(tabulist[[i]][1]==movevertices[v] & tabulist[[i]][2]==bestinsertpathnum[v]){
         tbd[a]=v
       }
     }
  }
  if(length(tbd)>0){
    qvec=qvec[-tbd]
  }
  }
  for (v in qvec) {
    tempsolution=list()
    tempsolution=pathlist
    
    if(rmvtype[v]==1){
      ##print("ATTEMPTING TYPE 1 RMV IJK")
      ##print(c(bestt1irmv[v],bestt1jrmv[v],bestt1krmv[v]))
      ##print("ORIGINALRMVPATH T1")
      ##print(pathlist[[perturbedpathnum[v]]])
    tempsolution[[perturbedpathnum[v]]]=type1unstringing(tempsolution[[perturbedpathnum[v]]],bestt1irmv[v],bestt1jrmv[v],bestt1krmv[v])[[1]]
    ##print("NEWREMOVEPATH")
    ##print(tempsolution[[perturbedpathnum[v]]])
    }else if(rmvtype[v]==2){
      ##print("ATTEMPTING TYPE 2 RMV IJK")
      ##print(c(bestt2irmv[v],bestt2jrmv[v],bestt2krmv[v]))
      
      tempsolution[[perturbedpathnum[v]]]=type2unstringing(pathlist[[perturbedpathnum[v]]],bestt2irmv[v],bestt2jrmv[v],bestt2krmv[v],bestt2lrmv[v])[[1]]
      ##print("ORIGINALRMVPATH T2")
      ##print(pathlist[[perturbedpathnum[v]]])
      ##print("NEWREMOVEPATH")
      ##print(tempsolution[[perturbedpathnum[v]]])
      }
    if(instype[v]==1){
     
      ##print("BESTINSERTPATHNUM")
      ##print(bestinsertpathnum)
      ##print("MOVEVERTICE")
      ##print(movevertices[v])
      ##print(tempsolution)
      ##print(tempsolution[[1]])
      ##print("BEFORE INSERTION T1")
      ##print(tempsolution[[bestinsertpathnum[v]]])
      ##print("INSERTION PARAMETERS")
      ##print(c(bestt1i[v],bestt1j[v],bestt1k[v]))
    tempsolution[[bestinsertpathnum[v]]]=type1insertion(movevertices[v],tempsolution[[bestinsertpathnum[v]]],bestt1i[v],bestt1j[v],bestt1k[v])
    ##print("AFTER INSERTION T1")
    ##print(tempsolution[[bestinsertpathnum[v]]])
    
    }else if(instype[v]==2){
      ##print("BESTINSERTPATHNUM")
      ##print(bestinsertpathnum)
      ##print("MOVEVERTICE")
      ##print(movevertices[v])
      ##print(tempsolution)
      ##print(tempsolution[[1]])
      ##print("BEFORE INSERTION T2")
      ##print(tempsolution[[bestinsertpathnum[v]]])
      
      tempsolution[[bestinsertpathnum[v]]]=type2insertion(movevertices[v],pathlist[[bestinsertpathnum[v]]],bestt2i[v],bestt2j[v],bestt2k[v],bestt2l[v])
      ##print("AFTER INSERTION T2")
      ##print(tempsolution[[bestinsertpathnum[v]]])
      
      }
    ##print("LOL6")
    ##print("TEMPSOLUTION")
    ##print(tempsolution)
    mdf1objfun[v]=SAobjfun(tempsolution,adjacency)
    mdf2objfun[v]=F2objfun(tempsolution,alphapm,betapm,lengthconstraint,capacityconstraint,adjacency,txy)
    #deltamax=1
    #dv=1
    ##print("MD2OBJFUN")
    ##print(mdf2objfun)
    ##print("g")
    ##print(g)
    
    m=length(pathlist)
    ##print("m")
    ##print(m)
    ##print("FV")
    ##print(fv)
    ##print("deltamax")
    ##print(deltamax)
    if(mdf2objfun[v]>F2objfun(pathlist,alphapm,betapm,lengthconstraint,capacityconstraint,adjacency,txy)){
      ##print("lol6.5")
      mdf2objfun[v]=mdf2objfun[v]+deltamax*sqrt(m)*g*fv[movevertices[v]]
    }
  }
  ##print("LOL7")
  ##print(mdf2objfun)
   #select best move
  bestv=which(mdf2objfun==min(mdf2objfun))
  #implement best move
  newpathlist=list()
  newpathlist=pathlist
  ##print("LOL8")
  print(bestv)
  print(rmvtype)
  if(rmvtype[bestv]==1){
    print("NOW REALLY T1 RMV I J K")
    print(c(bestt1irmv[bestv],bestt1jrmv[bestv],bestt1krmv[bestv]))
    print("ORIGINAL PATH")
    print(newpathlist[[perturbedpathnum[bestv]]])
    newpathlist[[perturbedpathnum[bestv]]]=type1unstringing(newpathlist[[perturbedpathnum[bestv]]],bestt1irmv[bestv],bestt1jrmv[bestv],bestt1krmv[bestv])[[1]]
    print("NEW PATH")
    print(newpathlist[[perturbedpathnum[bestv]]])
  }else if(rmvtype[bestv]==2){
    print("NOW REALLY T2 RMV I J K L")
    #print(c(bestt2irmv[bestv],bestt2jrmv[bestv],bestt2krmv[bestv],bestt2lrmv[bestv]))
    #print("ORIGINAL PATH")
    #print(newpathlist[[perturbedpathnum[bestv]]])
    newpathlist[[perturbedpathnum[bestv]]]=type2unstringing(newpathlist[[perturbedpathnum[bestv]]],bestt2irmv[bestv],bestt2jrmv[bestv],bestt2krmv[bestv],bestt2lrmv[bestv])[[1]]
    #print("NEW PATH")
    #print(newpathlist[[perturbedpathnum[bestv]]])
  }else if(rmvtype[bestv]==0){
    print("SIMPLE REMOVE")
    newpathlist[[perturbedpathnum[bestv]]]=newperturbedpath[[bestv]]
  }
  ##print("LOL9")
  print(instype)
  print(instype[bestv])
  if(instype[bestv]==1){
    print("INSERTVERTEX")
    print(movevertices[bestv])
    print("I J K")
    #print(c(bestt1i[bestv],bestt1j[bestv],bestt1k[bestv]))
    print("BEFORE T1 INSERTION")
    #print(newpathlist[[bestinsertpathnum[bestv]]])
    newpathlist[[bestinsertpathnum[bestv]]]=type1insertion(movevertices[bestv],newpathlist[[bestinsertpathnum[bestv]]],bestt1i[bestv],bestt1j[bestv],bestt1k[bestv])
    #print("AFTER INSERTION")
    #print(newpathlist[[bestinsertpathnum[bestv]]])
    }else if(instype[bestv]==2){
      #print("INSERTVERTEX")
      #print(movevertices[bestv])
      #print("I J K L")
      #print(c(bestt2i[bestv],bestt2j[bestv],bestt2k[bestv],bestt2l[bestv]))
      print("BEFORE T2 INSERTION")
      #print(newpathlist[[bestinsertpathnum[bestv]]])
      
    newpathlist[[bestinsertpathnum[bestv]]]=type2insertion(movevertices[bestv],newpathlist[[bestinsertpathnum[bestv]]],bestt2i[bestv],bestt2j[bestv],bestt2k[bestv],bestt2l[bestv])
    print("AFTER INSERTION")
    #print(newpathlist[[bestinsertpathnum[bestv]]])
    }else if(instype[bestv]==0){
      print("UNDOING REMOVAL SINCE NO INSERTION WAS FOUND")
      print(bestinsertpathnum[bestv])
      newpathlist[[perturbedpathnum[bestv]]]=pathlist[[perturbedpathnum[bestv]]]
      print("UNDONE!")
    }
  consistencycheck(newpathlist)
  #STEP4
  #check if US needs to be used
  #condition 1
  cond1=F2objfun(pathlist,alphapm,betapm,lengthconstraint,capacityconstraint,adjacency,txy)<F2objfun(newpathlist,alphapm,betapm,lengthconstraint,capacityconstraint,adjacency,txy)
  #condition2 New solution is feasible
  cond2[iter]=feasabilitycheck(newpathlist,lengthconstraint,capacityconstraint,adjacency,txy)==1
  print("FEASIBLE?")
  print(cond2)
  #Condition3 US has not been used at iteration t-1
  cond3=lastUSuse!=(iter-1)
  numpaths=length(newpathlist)
  if(cond1 & cond2[iter] & cond3){
    print("APPLYING US POSTOP")
    for(a in 1:numpaths){
      ##print("BEFORE US")
      ##print(newpathlist[[a]])
      newpathlist[[a]]=USTSP(newpathlist[[a]],adjacency,min(p1,p2),length(newpathlist[[a]]))
      ##print("AFTER US")
      ##print(newpathlist[[a]])
      }
  lastUSuse=iter
  consistencycheck(newpathlist)
  }
  #STEP 5 - UPDATE
  #update TABULIST if US has not been used
  if(!cond1 |!cond2[iter] | !cond3){
    #tabu record has 4 parts: moved vertex, inserted path, iteration when move is declared tabu and when it is removed from tabu list
    numtabus=length(tabulist)
    #print("NUMTABUS")
    #print(numtabus)
    #print("TABULIST")
    #print(tabulist)
    tabudur=sample(thetamin:thetamax,1)
    tabulist[[numtabus+1]]=c(movevertices[bestv],perturbedpathnum[bestv],iter,iter+tabudur)
    #check for removableelements of the tabulist
    
    if(numtabus>0){
      tbd=c()
      a=1
    for (t in 1:numtabus) {
      #print("T")
      #print(t)
      if(tabulist[[t]][4]==iter){
        #print("TBLIST")
        #print(tabulist)
        tbd[a]=t
        a=a+1
      }
    }
      if(length(a)>0){
        tabulist[[a]]=NULL
      }
    }
    }
  #update fv, deltamax, m, bestsolutions,bestobjfunvalues
  if(cond2[iter]|iter<nmax){
    if(bestf1>SAobjfun(newpathlist,adjacency)){
      bestfeasiblesolution=newpathlist
    }
  bestf1=min(bestf1,SAobjfun(newpathlist,adjacency))
  histf1[iter]=SAobjfun(newpathlist,adjacency)
  ##print("HISTF1 FIRST")
  ##print(histf1)
  }else{
      if(iter>1){         histf1[iter]=histf1[iter-1]}
  }
  if(bestf2>F2objfun(newpathlist,alphapm,betapm,lengthconstraint,capacityconstraint,adjacency,txy)){
    bestunfeasiblesolution=newpathlist
  }
  bestf2=min(bestf2,F2objfun(newpathlist,alphapm,betapm,lengthconstraint,capacityconstraint,adjacency,txy))
  fv[movevertices[bestv]]=fv[movevertices[bestv]]+1
  histf2[iter]=F2objfun(newpathlist,alphapm,betapm,lengthconstraint,capacityconstraint,adjacency,txy)
  iter=iter+1
  ##print("DELTAMAX UPDATE")
  ##print("HISTf1")
  ##print(histf1)
  ##print(max(abs(diff(histf1))))
  ##print(diff(histf1))
  if(!is.nan(max(deltamax,max(abs(diff(histf1)))))){
  deltamax=max(deltamax,max(abs(diff(histf1))))}
  pathlist=newpathlist
  #print("ITER")
  #print(iter)
  #STEP 6 PENALTY ADJUSTMENT
  if(prod(cond2[max(2,iter-nmax):(iter-1)])==1){
    alphapm=2*alphapm
    betapm=2*betapm
  }else if(sum(cond2[max(2,iter-nmax):(iter-1)])==length(cond2[max(2,iter-nmax):(iter-1)])){
    alphapm=0.5*alphapm
    betapm=0.5*betapm
  }
  #STEP7 TERMINATION CHECK
  ##print("TERMCHECK")
  ##print(bf1step)
  ##print(bf2step)
  ##print((iter-bf1step)>nmax)
  ##print((iter-bf2step)>nmax)
  ##print((((iter-bf1step)>nmax) & ((iter-bf2step)>nmax))|iter>100)
  
  if(iter>nmax){
    #at which step were the bestf1 and bestf2 found
    if(!is.nan(which(na.omit(histf1)==min(na.omit(histf1))))){
    bf1step=min(which(histf1==min(histf1)))}
    if(!is.nan(which(histf2==min(histf2))))
    bf2step=min(which(histf2==min(histf2)))
  }
  #print("BF1STEP")
  #print(bf1step)
  #VISUAL INTERFACE
  #OPEN PLOT WITH 2 windows: objfunction and current solution
  
  #plot final best solution
  plot(txy,xlim=c(0,max(txy[,1])),ylim=c(0,max(txy[,2])),main="PATHS",cex.lab=1.1)
  
  numpath=length(pathlist)
  for (i in 1:numpath) {
    
    len=length(pathlist[[i]])-1
    
    #loop for each path
    for (j in 1:len) {
      segments(txy[pathlist[[i]][j],1],txy[pathlist[[i]][j],2],txy[pathlist[[i]][j+1],1],txy[pathlist[[i]][j+1],2],col = rainbow(numpath)[i])
    }
  }
  
  plot( na.omit(histf1), xlim=c(0,max(nmax,iter)), col = "blue",ylim=c(0,max(na.omit(c(histf1,100)))),main = c("OBJFUN, BEST SO FAR",min(na.omit(histf1))," AT STEP ",bf1step, "OBJFUNVAR",objfunvar), cex.lab = 1.1 ,type = "l")
  #CALCULATE VARIANCE OF OBJECTIVE FUNCTION FOR NEW STOPPING CRITERIA
  if(iter>3){
  objfunvar=var(histf1[max(1,(iter-nmax)):(iter-1)])
  varcondition=TRUE
  print("HISTF1")
  print(histf1)
  #histf1[max(1,(iter-nmax)):(iter-1)]
  ##print("ITER")
  ##print(iter)
  ##print("TART")
  ##print(max(1,(iter-nmax)):iter)
  ##print("STARTITER")
  ##print(max(1,(iter-nmax)))
  print("OBJFUNVAR")
  print(objfunvar)
  if((objfunvar<(histf1[(iter-1)]*0.02)&iter>(nmax*1.5)&bf1step<((iter-nmax)/2))){
    varcondition=FALSE
  }}
  
  
  print((((iter-bf1step)>nmax) & ((iter-bf2step)>nmax))|iter>100)
  print("VARCOND")
  print(varcondition)
  #
  #print((iter-bf1step)>nmax)
  #print((iter-bf2step)>nmax)
  #print(iter)
  
#print(!((((iter-bf1step)>nmax) & ((iter-bf2step)>nmax))|iter>100 |!varcondition))
   ##print("LOL10") 
  }
  
  #print(histf1)
  #print(histf2)
  
  return(bestfeasiblesolution)
}