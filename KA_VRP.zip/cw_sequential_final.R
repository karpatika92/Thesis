cw_sequential_final=function(txy,adjacency,maxlength,maxcap){
  
  
  #Clarke-Wright algorithm
  #Create a list of paths that contain only 1 vertex
  #list of paths containing all visited vertices
  paths=list()
  pathlengths=list()
  pathcap=list()
  #vector that tells you the number of the parth the ith vertex is in
  points_in_path=c(rep(0,length(txy[,1])))
  numpoints=length(txy[,1])-1
  for (i in 1:(length(txy[,1])-1)) {
    paths[[i]]=c(length(txy[,1]),i,length(txy[,1]))
    pathlengths[[i]]=adjacency[paths[[i]][1],paths[[i]][2]]
    pathcap[[i]]=txy[i,3]
    points_in_path[i]=i
  }
  #calculate total length
  objfun=Reduce("+",pathlengths,accumulate = FALSE)
  #calculate the sequantial list for adding points to a path http://pure.au.dk/portal-asb-student/files/36025757/Bilag_E_SAVINGSNOTE.pdf
  #formula for savings: c0j+ci0-cij
  #savings for all custome pairs
  savings=matrix(rep(0,np*nc*np*nc),nrow=np*nc,ncol=np*nc)
  for (i in 1:(np*nc)) {
    for (j in i:(np*nc)) {
      if(!(j==i)){
        savings[i,j]=adjacency[i,np*nc+1]+adjacency[np*nc+1,j]-adjacency[i,j]
        
      }
    }
  }
  
  #now calculate the best moves
  m=1
  moves=list()
  savings2=savings
  for (i in 1:(np*nc)) {
    for (j in i:(np*nc)) {
      if(savings2[which(savings2==max(savings2))]==0){break}
      moves[[m]]=which(savings2==max(savings2),arr.ind=TRUE)
      
      savings2[moves[[m]]]=0
      m=m+1
      
    } 
  }
  
  #now start executing the moves
  m=length(moves)
  print("CW2 MOVES")
  print(m)
  for (j in 1:m){
    actualroute=points_in_path[moves[[j]][1]]
    for (i in j:m) {
      
      
      target=moves[[i]][1]
      candidate=moves[[i]][2]
      targetroute=points_in_path[target]
      candidateroute=points_in_path[candidate]
      #in the sequential route construction, we nly modify 1 route at a time
      #check if the target route is the currently edited route
      if(actualroute==targetroute){
        
        #check feasibility conditions
        #capacity
        feasible_cap=pathcap[[targetroute]]+txy[candidate,3]<maxcap
        #length - NOT YET
        feasible_len=pathlength(c(paths[[targetroute]],candidate,numpoints),adjacency)<maxlength
        
        #pathlengths[[targetroute]]+
        #is the point already moved?
        movable=length(paths[[points_in_path[candidate]]])==3
        #if capacity and length are OK, then we add the vertice to the path
        if(feasible_cap & movable & feasible_len){
          #insertion
          index=which(paths[[targetroute]]==target)
          val=c(paths[[targetroute]],candidate)
          id=c(seq_along(paths[[targetroute]]),index+0.5)
          paths[[targetroute]]=val[order(id)]
          #update path capacity
          pathcap[[targetroute]]=pathcap[[targetroute]]+txy[candidate,3]
          pathcap[[candidateroute]]=0
          #update path lengths
          pathlengths[[candidateroute]]=0
          pathlengths[[targetroute]]=pathlength(paths[[targetroute]],adjacency)
          #delete original path
          paths[[points_in_path[candidate]]]="NaN"
          #update point location
          points_in_path[candidate]=targetroute
          #update objective function
          objfun=Reduce("+",pathlengths)
        }
        
      }
    }
    
  }
  
  
  emptypath=c(0)
  j=1
  #remove empty entries from the pathlists
  for (i in 1:length(paths)) {
    if(paths[[i]]=="NaN"){
      emptypath[j]=i
      j=j+1
    }
  }
  paths[emptypath]=NULL
  pathlengths=pathlengths[pathlengths!=0]
  return(paths)
  
  
  
}

  