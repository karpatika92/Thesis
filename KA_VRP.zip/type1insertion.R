type1insertion=function(insertvertex,path,vipos,vjpos,vkpos){
  newpath=c(rep(0,length(path)+1))
  #check is vk meets the necessary conditions
    #that is vk is between vj and vi 
    #get positions of all 3 vertices
      vi=path[vipos]
      vj=path[vjpos]
      vk=path[vkpos]
      vkok=vjpos<vkpos & vkpos<length(path)
      vivjok=vipos<vjpos & 1<vipos & vjpos<length(path)
      #check the condition that this is indeed a type 1 insertion
      type1ok= vkpos!=vipos & vkpos!=vjpos
      ##print("VKOK T1OK VIVJOK INSERTION")
      ##print(c(vkok,type1ok,vivjok))
      ##print("I J K")
      ##print(c(vipos,vjpos,vkpos))
      
      if(vkok & type1ok & vivjok){
        #construct the new path
        #the beginning is the same until vi
        for (i in 1:vipos) {
          newpath[i]=path[i]
        }
        ###print(newpath)
        ##print("Phase 1 done")
        #then comes the inserted vertex and vj
        newpath[vipos+1]=insertvertex
        newpath[vipos+2]=vj
        npi=vipos+3
        ##print(newpath)
        ##print("Phase2 done")
        #then from vj to vi-1
        if((vjpos-1)>(vipos+1)){
          ##print("LOLLLL")
        for (i in (vjpos-1):(vipos+1)) {
          newpath[npi]=path[i]
          npi=npi+1
        }}else{
          if(!is.element(path[vipos+1],newpath)){
            newpath[npi]=path[vipos+1]
            npi=npi+1
          }
        }
        ##print(newpath)
        ##print("Phase3 is done")
        #the next one is vk
        ##print(npi)
        newpath[npi]=path[vkpos]
        npi=npi+1
        #then reversed path from vk to vj+1 if there is a path
        #otherwise just insert 1 vertice
        if((vkpos-1)>(vjpos+1)){
          ##print("lol")
          ##print(vkpos-1)
          ##print(vjpos+1)
        for (i in (vkpos-1):(vjpos+1)) {
          newpath[npi]=path[i]
          npi=npi+1
        }}else{
          if(!is.element(path[vjpos+1],newpath)){newpath[npi]=path[vjpos+1]
        npi=npi+1}}
        
        ##print(newpath)
        ##print("Phase4 is done")
        #then vk+1 if it is not the end
        if((vkpos+1)<length(path)){
        newpath[npi]=path[vkpos+1]
        npi=npi+1}
        #then the rest is the same IF there is still something
        if((vkpos+2)<(length(path))){
        for (i in (vkpos+2):(length(path))) {
          newpath[npi]=path[i]
          npi=npi+1
        }}else{newpath[npi]=path[length(path)]}
      
        }else{
        newpath=path
        ##print("Unfeasible insertion")
        ##print(type1ok)
        ##print(vkok)
        ##print(vivjok)
      }
      return(newpath)
}

