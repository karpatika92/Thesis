soleval=function(pathlist,adjacency,lengthconstraint,capacityconstraint,txy){
  numpaths=length(pathlist)
  lengths=rep(0,numpaths)
  caps=rep(0,numpaths)
  for(i in 1:numpaths){
    lengths=pathlength(pathlist[[i]],adjacency)
    caps=sum(txy[pathlist[[i]],3])
  }
  lenuse=sum(rep(lengthconstraint,numpaths)-lengths)/numpaths
  print(lenuse)
  
  capuse=sum(rep(capacityconstraint,numpaths)-caps)/numpaths
  returnlist=rep(0,3)
  returnlist[1]=numpaths
  returnlist[2]=lenuse
  returnlist[3]=capuse
  return(returnlist)
}