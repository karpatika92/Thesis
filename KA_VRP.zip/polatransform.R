polartransform=function(txy,adjacency){
  
  ##Convert xy coordinates to polar coordinates
  ##subtract the coordinates of the depot from every pair so that the data is centered
  numpoints=np*nc
  depox=txy[numpoints+1,1]
  depoy=txy[numpoints+1,2]
  
  txy[,1]=txy[,1]-depox
  txy[,2]=txy[,2]-depoy
  
  #Sweep algorithm
  #list of paths containing all visited vertices

  
  ##convert to polar coordinates
  #angle by arc tangent
  #pxy=matrix(nrow = numpoints+1,ncol=3)
  txy=cbind(txy,atan2(txy[,2],txy[,1])*180/pi)
  #pxy[,1][pxy[,1]<0]=pxy[,1][pxy[,1]<0]+360
  #distance from the origin
 #Z print("NUMPOINTS")
#  print(numpoints)
 # print(adjacency)
  #print(length(adjacency[91,]))
  #print(adjacency[,90])
  txy=cbind(txy,adjacency[,numpoints+1])
  #pxy[,2]=adjacency[,numpoints+1]
  #copy the capacities
  
  #remove depo before sorting
  #pxy=pxy[-nrow(pxy),]
  txy=txy[-nrow(txy),]
  
  
  
  #sort according to angle
  txy=txy[order(txy[,4]),]
  
  #pxy=pxy[order(pxy[,1]),]
  
  
  #add the depo as last again
  #pxy=rbind(pxy,c(0,0,0))
  txy=rbind(txy,c(rep(0,length(txy[1,]))))
  #add labels
  #pxy=cbind(pxy,c(seq(1:numpoints),0))
  txy=cbind(txy,c(seq(1:numpoints),0))
  
  #compute new distance matrix
 returnlist=list()
 returnlist[[1]]=txy
}