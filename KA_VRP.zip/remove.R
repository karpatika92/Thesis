remove=function(removevertex,path){
  path=path[-removevertex]
  return(path)
}
  