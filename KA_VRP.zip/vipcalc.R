vertexinpathcalc=function(pathlist){
    #pathlist must be a list
    #every vertex is contained in exactly 1 path
    numpaths=length(pathlist)
    pathlengths2=rep(0,numpaths)
    for (i in 1:numpaths) {
      pathlengths2[i]=length(pathlist[[i]])
    }
    numvertices=sum(pathlengths2)-numpaths*2
    vertexinpath=rep(0,numvertices)
    #print("PATHLIST IN CONSCHEK")
    #print(pathlist)
    #print("NUMPATHS IN CONSCHECK")
    #print(numpaths)
    #print("PATHLENGTHS2 in CONSCHECK")
    #print(pathlengths2)
    for (i in 1:numpaths) {
      for (j in 2:(pathlengths2[i]-1)) {
        
        
        
        if(vertexinpath[ pathlist[[i]][j] ]==0){
          vertexinpath[ pathlist[[i]][j] ]=i}else{
            print("VERTIEX IN MULTIPLE PATHS")
            print(        c("PATH 1 ",vertexinpath[pathlist[[i]][j]],"PATH2 ",i,"VERTEX: ",pathlist[[i]][j]))
            print("PATHLIST")
            print(pathlist)
            
            violation1=TRUE
          }
      }
    }
    return(vertexinpath)
}