GENIUSTSP=function(vertexset,adjacency,p){
  source("C:\\Users\\karpatika\\Documents\\pathlength.R")
  source("C:\\Users\\karpatika\\Documents\\3_opt.R")
  source("C:\\Users\\karpatika\\Documents\\type1insertion.R")
  source("C:\\Users\\karpatika\\Documents\\type1inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2inscost.R")
  source("C:\\Users\\karpatika\\Documents\\type2insertion.R")
  source("C:\\Users\\karpatika\\Documents\\remove.R")
  source("C:\\Users\\karpatika\\Documents\\pnbhd.R")
  #select 3 arbitrary vertices
  numvertices=length(vertexset)
  tour=sample(1:numvertices,4,replace=FALSE)
  t2=0
  #initialize the p-nbhd of all vertices
  nbhood=list()
  for (i in 1:numvertices) {
    nbhood[[i]]=tour[pnbhd(i,p,adjacency[,tour])]
  }
  tour[5]=tour[1]
  #STEP2
  for (a in 1:(numvertices-4)) {
    
  
  
  #logical vector stores if a vertex is on the tour
  onthetour=c(rep(0,numvertices))
  for (i in 1:numvertices) {
    onthetour[i]=is.element(i,tour)
  }
  
  outsidevertexset=vertexset[!onthetour]
  insertable=length(outsidevertexset)
  #numvertices=length(vertexset)
  insertvertexnum=sample(1:insertable,1,replace=FALSE)
  insertvertex=outsidevertexset[insertvertexnum]
  print(insertvertex)
  #initial insertion cost is infinite
  bestinscost=99999
  besti=0
  bestj=0
  bestk=0
  #try every possible type1 insertion
  for (i in 1:min(p,length(tour)-1)) {
    for (j in 1:min(p,length(tour)-1)) {
      for (k in 1:min(p,length(tour)-1)) {
        #print(c(i,j,k))
        vi=nbhood[[insertvertex]][i]
        vipos=match(vi,tour)
        vip1=tour[vipos+1]
        vj=nbhood[[insertvertex]][j]
        vjpos=match(vj,tour)
        vk=nbhood[[vip1]][k]
        vkpos=match(vk,tour)
        t1inscost=type1inscost(tour,insertvertex,vipos,vjpos,vkpos,adjacency)
        #print(c(vipos,vjpos,vkpos))
        if(t1inscost < bestinscost){
          besti=vipos
          bestj=vjpos
          bestk=vkpos
          #print("found a better one!")
          #print(c("New Best: ",inscost))
          #print(c("Old Best: ",bestinscost))
          bestinscost=t1inscost
          bestt1inscost=t1inscost
          type=1
        }
      }
    }
  }
  bestinscost=99999
  bestt2inscost=99999
    #try every possible type2 insertion
  for (i in 1:min(p,length(tour)-1)) {
    for (j in 1:min(p,length(tour)-1)) {
      for (k in 1:min(p,length(tour)-1)) {
      for (l in 1:min(p,length(tour)-1)) {
        
        vi=nbhood[[insertvertex]][i]
        vipos=match(vi,tour)
        vip1=tour[vipos+1]
        vj=nbhood[[insertvertex]][j]
        vjpos=match(vj,tour)
        vjp1=tour[vjpos+1]
        vk=nbhood[[vip1]][k]
        vkpos=match(vk,tour)
        vl=nbhood[[vjp1]][l]
        vlpos=match(vl,tour)
        
        t2inscost=type2inscost(tour,insertvertex,vipos,vjpos,vkpos,vlpos,adjacency)
        if(t2inscost<bestinscost){
          #type=2
          bestt2inscost=t2inscost
          bestinscost=t2inscost
          t2besti=vipos
          t2bestj=vjpos
          t2bestk=vkpos
          t2bestl=vlpos
        }
        
      }
        }
    }
  }
  
  
  
  #execute best move
  print(c("Best t1 inscost is: ",bestt1inscost))
  print(c("Best t2 inscost is: ",bestt2inscost))
  if(bestt2inscost<bestt1inscost){type=2}else{type=1}
  if(type==1){
  tour=type1insertion(insertvertex,tour,besti,bestj,bestk)
  print("Type1 move executed!")
  }else{if(type==2){
    tour=type2insertion(insertvertex,tour,t2besti,t2bestj,t2bestk,t2bestl)
    print("Type2 move executed")
    t2=t2+1}else{print("THIS IS BS")}}
  
  print(tour)
  #print(c(besti,bestj,bestk))
  #update p-nbhd of all vertices
  nbhood=list()
  for (i in 1:numvertices) {
    nbhood[[i]]=tour[pnbhd(i,p,adjacency[,tour])]
  }
}
print(t2)
return(tour)
  }