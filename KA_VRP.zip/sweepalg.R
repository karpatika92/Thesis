rm(list=ls())
set.seed(2121434)
graphics.off()

require(stats)
source("C:\\Users\\karpatika\\Documents\\pathlength.R")

#Generate random points in clusters
#number of clusters
nc=9
#number of point sin each cluster
np=10
row=3
column=nc/row
xy=array(dim=c(np,2,nc))
#specify shift
shift=2
#specify capacity
maxcap=3
#¶specify max tour length
maxlength=30

#2 nested for cycles for row and column
for (i in 1:row) {
  for (j in 1:column) {
    xy[, ,(i-1)*row+j]=matrix(runif(np*2),ncol=2)+matrix(nrow=np,ncol=2,data=c(rep(shift*(i-1),np),rep(shift*(j-1),np)))
    
  }
}

txy=xy[, ,1]
for (i in 2:nc) {
  txy=rbind(txy,xy[,,i])
}
#generate x and y coordinates of points
txy=rbind(txy,c(2.5,2.5))
#so the data is generated
#generate euclidean distance matrix by calculating the distance of each pointpair with 2 for cycles
adjacency=as.matrix(dist(txy))
#assign capacities to points
cap=runif(length(txy[,1])-1,min=0,max=1)
#attach capacities to point matrix
txy=cbind(txy,c(cap,0))
#########################################################################

##Convert xy coordinates to polar coordinates
##subtract the coordinates of the depot from every pair so that the data is centered
numpoints=np*nc
depox=txy[numpoints+1,1]
depoy=txy[numpoints+1,2]

txy[,1]=txy[,1]-depox
txy[,2]=txy[,2]-depoy

#Sweep algorithm
#list of paths containing all visited vertices
paths=list()
pathlengths=list()
pathcap=list()

##convert to polar coordinates
#angle by arc tangent
#pxy=matrix(nrow = numpoints+1,ncol=3)
txy=cbind(txy,atan2(txy[,2],txy[,1])*180/pi)
#pxy[,1][pxy[,1]<0]=pxy[,1][pxy[,1]<0]+360
#distance from the origin
txy=cbind(txy,adjacency[,numpoints+1])
#pxy[,2]=adjacency[,numpoints+1]
#copy the capacities

#remove depo before sorting
#pxy=pxy[-nrow(pxy),]
txy=txy[-nrow(txy),]



#sort according to angle
txy=txy[order(txy[,4]),]

#pxy=pxy[order(pxy[,1]),]


#add the depo as last again
#pxy=rbind(pxy,c(0,0,0))
txy=rbind(txy,c(rep(0,length(txy[1,]))))
#add labels
#pxy=cbind(pxy,c(seq(1:numpoints),0))
txy=cbind(txy,c(seq(1:numpoints),0))

#compute new distance matrix
adjacency=as.matrix(dist(txy[,1:2]))

#create an empty path
paths[[1]]=c(numpoints+1)
pathlengths[[1]]=0
pathcap[[1]]=0
j=1
#start creating clusters
for (i in 1:numpoints) {
    
    #check if adding it to the path violates capacity constraints
  capconst=pathcap[[j]]+txy[i,3]<maxcap
  if(capconst){
    #add vertice to path
    paths[[j]]=c(paths[[j]],i)
    #update capacity of path
    pathcap[[j]]=pathcap[[j]]+txy[i,3]
  }else{
    #if it is not possible, then finish the original path and start a new one
    paths[[j]]=c(paths[[j]],numpoints+1)
    pathlengths[[j]]=pathlength(paths[[j]],adjacency)
    j=j+1
    paths[[j]]=c(numpoints+1,i)
    pathcap[[j]]=0
  }
  

}
#add tour to the depo to the last path
paths[[j]]=c(paths[[j]],numpoints+1)

#check every 2 permutation in a route
numpaths=length(paths)
for (i in 1:numpaths) {
  
  l=length(paths[[i]])
  if(l>3){
  for (j in 2:(l-2)) {
    for (k in (j+1):(l-1)) {
      newroute=replace(paths[[i]],c(j,k),paths[[i]][c(k,j)])
      if( pathlength(newroute,adjacency) < pathlength(paths[[i]],adjacency) ) {
        paths[[i]]=newroute
        objfun=Reduce("+",pathlengths)
        k=j+1
      }
    }
    
  }
  }
  pathlengths[i]=pathlength(paths[[i]],adjacency)
  
}
#drawing the final solution
dev.new(width=5, height=4)
plot(txy[,1],txy[,2],xlim=c(-2.5,2.5),ylim=c(-2.50,2.5),col="black")
#loop for every path
numpath=length(paths)
for (i in 1:numpath) {
  
  
  #loop for each path
  len=length(paths[[i]])-1
  for (j in 1:len) {
    segments(txy[paths[[i]][j],1],txy[paths[[i]][j],2],txy[paths[[i]][j+1],1],txy[paths[[i]][j+1],2],col = rainbow(numpath)[i])
    
  }
}
#calculate objective function
objfun=Reduce("+",pathlengths,accumulate = FALSE)

objfun
