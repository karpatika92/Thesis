type1inscost=function(tour,insertvertex,vipos,vjpos,vkpos,adjacency){
  #check is vk meets the necessary conditions
  #that is vk is between vj and vi 
  #get positions of all 3 vertices
  vi=tour[vipos]
  vj=tour[vjpos]
  vk=tour[vkpos]
  
  vkok= vjpos < vkpos & vkpos<length(tour)
  vivjok=vipos<vjpos & 1<vipos & vjpos<length(tour)
  #check the condition that this is indeed a type 1 insertion
  type1ok= vkpos!=vipos & vkpos!=vjpos
  ###print("VKOK T1OK VIVJOK COST")
  ##print(c(vkok,type1ok,vivjok))
  ##print("I J K")
  ##print(c(vipos,vjpos,vkpos))
  
  if(vkok & type1ok & vivjok){
    inscost=adjacency[tour[vipos],insertvertex]+adjacency[insertvertex,tour[vjpos]]+adjacency[tour[vipos+1],tour[vkpos]]+adjacency[tour[vjpos+1],tour[vkpos+1]]-adjacency[tour[vipos],tour[vipos+1]]-adjacency[tour[vjpos],tour[vjpos+1]]-adjacency[tour[vkpos],tour[vkpos+1]]
  }else{
    inscost=9999999
    ##print(vkok)
    ##print(type1ok)
    ##print(vivjok)
  }    
  return(inscost)
}