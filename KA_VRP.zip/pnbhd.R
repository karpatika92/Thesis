pnbhd=function(vertex,p,adjacency){
  l=length(adjacency[vertex,])
  nbhd=c(rep(0,min(p,l)))
  
  if(l>p){
  for (i in 1:p) {
    nbhd[i]=which(adjacency[vertex,]==sort(adjacency[vertex,])[i+1])
  }}else{
    for (i in 1:l) {
      nbhd[i]=which(adjacency[vertex,]==adjacency[vertex,i])
    }
  }
  return(nbhd)
}