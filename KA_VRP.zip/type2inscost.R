type2inscost=function(tour,insertvertex,vipos,vjpos,vkpos,vlpos,adjacency){
  isontour=!is.element(insertvertex,tour)
  pl=length(tour)
  plok=pl>5
  vivjok=vipos<vjpos
  vkok=vkpos!=vjpos & vkpos!=(vjpos+1) & vkpos>vjpos
  vlok=vlpos!=vipos & vlpos!=(vipos+1) & vlpos>vipos & vlpos<vjpos
  if(plok&vivjok&vkok&vlok&isontour){
    ##print(vlok)
    vi=tour[vipos]
    vj=tour[vjpos]
    vk=tour[vkpos]
    vl=tour[vlpos]
    vip1=tour[vipos+1]
    vjp1=tour[vjpos+1]
    vkm1=tour[vkpos-1]
    vlm1=tour[vlpos-1]
    inscost=adjacency[vi,insertvertex]+adjacency[insertvertex,vj]+adjacency[vl,vjp1]+adjacency[vkm1,vlm1]+adjacency[vip1,vk]-adjacency[vi,vip1]-adjacency[vlm1,vl]-adjacency[vj,vjp1]-adjacency[vkm1,vk]
  }else{
    inscost=9999
  }
  return(inscost)
}